﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : PersonBL.cs                                                                     
 * Descripcion   : Clase para Manejar la Logica de Negocios para  la entidad Person                                                   
 * Autor         : Julio Cesar Robles Uribe - Jucer                                                
 * Fecha         : 24-May-2010                                                                               
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 24-May-2010    Jucer         1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;
//Librerias de DirTel
using DirTel.Entities;
using DirTel.DAL;

// NameSpace
namespace DirTel.BL
{
   /// <summary>
   /// Clase para manejar la logica de Negocios de la entidad Person
   /// </summary>
   public class PersonBL
   {
      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public PersonBL()
      {
      }
      #endregion Constructores

      //Metodos
      #region Metodos
      //Publicos
      #region Publicos
      /// <summary>
      /// Inserta los datos de la Persona
      /// </summary>
      /// <param name="person">Entidad con los datos de la persona</param>
      /// <returns>Identificador de la person</returns>
      public long CreatePerson(Person person)
      {
         // Crear el Objeto de Datos
         PersonDAL personDAL = new PersonDAL();

         // Ejecutar el Comando y retornar el id de la persona insertada
         long person_Id = personDAL.CreatePerson(person);

         // retornar el valor
         return person_Id;
      }

      /// <summary>
      /// Obtener todos los datos de las personas
      /// </summary>
      /// <returns>Lista con las personas</returns>
      public IList<Person> ReadAllPersons()
      {
         // Crear el Objeto de Datos
         PersonDAL personDAL = new PersonDAL();

         // Ejecutar el Comando
         IList<Person> lstPersons = personDAL.ReadAllPersons();

         return lstPersons;
      }

      /// <summary>
      /// Obtener los datos minimos de las personas
      /// </summary>
      /// <returns>Lista de Id y Nombres completos (Nombres y Apellidos)</returns>
      public IList<PersonLight> ReadAllPersonsLight()
      {
         // Crear el Objeto de Datos
         PersonDAL personDAL = new PersonDAL();

         // Ejecutar el Comando
         IList<PersonLight> lstPersonsLight = personDAL.ReadAllPersonsLight();

         return lstPersonsLight;
      }

      /// <summary>
      /// Borrar el Registro de la tabla segun el Id
      /// </summary>
      /// <param name="person_Id">Id de la persona</param>
      public void DeletePerson(long person_Id)
      {
         // Crear el Objeto de Datos
         PersonDAL personDAL = new PersonDAL();

         // Ejecutar el Comando 
         personDAL.DeletePerson(person_Id);
      }

      /// <summary>
      /// Actualiza los datos de la persona
      /// </summary>
      /// <param name="person">Entidad Persona</param>
      public void UpdatePerson(Person person)
      {
         // Crear el Objeto de Datos
         PersonDAL personDAL = new PersonDAL();

         // Ejecutar el Comando
         personDAL.UpdatePerson(person);

      }

      #endregion Publicos
      #endregion Metodos

   }
}
