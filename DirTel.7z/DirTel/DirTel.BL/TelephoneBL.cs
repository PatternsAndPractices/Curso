﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : TelephoneBL.cs                                                                      
 * Descripcion   : Clase para Manejar la Logica de Negocios para la entidad Telephone
 * Autor         : Julio Cesar Robles Uribe - Jucer                                                
 * Fecha         : 24-May-2010                                                                               
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 24-May-2010    Jucer         1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;
// Librerias de DirTel
using DirTel.Entities;
using DirTel.DAL;

// NameSpace
namespace DirTel.BL
{
   /// <summary>
   /// Clase para manejar la logica de Negocios de la entidad Telephone
   /// </summary>
   public class TelephoneBL
   {
      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public TelephoneBL()
      {
      }
      #endregion Constructores

      // Metodos
      #region Metodos

      // Publicos
      #region Publicos
      /// <summary>
      /// Inserta los datos del telefono
      /// </summary>
      /// <param name="telephone">Datos del Telefono</param>
      /// <returns>Identificador del Telefono</returns>
      public long CreateTelephone(Telephone telephone)
      {
         // Crear el Objeto de Datos
         TelephoneDAL telephoneDAL = new TelephoneDAL();

         // Ejecutar el Comando y retornar el id insertado
         long telephone_Id = telephoneDAL.CreateTelephone(telephone);

         //retornar el valor 
         return telephone_Id;

      }

      /// <summary>
      /// Obtener todos los telefonos de una persona
      /// </summary>
      /// <param name="person_Id">Identificador de la persona</param>
      /// <returns></returns>
      public IList<Telephone> ReadTelephonesByPersonId(long person_Id)
      {
         // Crear el Objeto de Datos
         TelephoneDAL telephoneDAL = new TelephoneDAL();

         // Ejecutar el Comando
         IList<Telephone> lstTelephones = telephoneDAL.ReadTelephonesByPersonId(person_Id);

         // retornar la lista
         return lstTelephones;
      }

      /// <summary>
      /// Obtener todos los datos de los Telefonos
      /// </summary>
      /// <returns>Lista con los datos de los telefonos</returns>
      public IList<Telephone> ReadAllTelephones()
      {
         // Crear el Objeto de Datos
         TelephoneDAL telephoneDAL = new TelephoneDAL();

         // Ejecutar el Comando
         IList<Telephone> lstTelephones = telephoneDAL.ReadAllTelephones();

         // retornar la lista
         return lstTelephones;
      }

      /// <summary>
      /// Borrar el Registro de la tabla segun el Id
      /// </summary>
      /// <param name="telephone_Id">Id a borrar</param>
      public void DeleteTelephone(long telephone_Id)
      {
         // Crear el Objeto de Datos
         TelephoneDAL telephoneDAL = new TelephoneDAL();

         // Ejecutar el Comando 
         telephoneDAL.DeleteTelephone(telephone_Id);

      }

      /// <summary>
      /// Actualiza los datos del telefono
      /// </summary>
      /// <param name="telephone">Datos del telefono</param>
      public void UpdateTelephone(Telephone telephone)
      {
         // Crear el Objeto de Datos
         TelephoneDAL personDAL = new TelephoneDAL();

         // Ejecutar el Comando
         personDAL.UpdateTelephone(telephone);
      }

      #endregion Publicos

      #endregion Metodos
   }
}
