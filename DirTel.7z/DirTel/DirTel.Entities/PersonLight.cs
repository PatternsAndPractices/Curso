﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : PersonLight.cs                                                                    
 * Descripcion   : Entidad para el manejo de los datos minimos de una persona (Id y Nombre)
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;

// NameSpace
namespace DirTel.Entities
{
   /// <summary>
   /// Clase para obtener los datos minimos de una persona
   /// </summary>
   public class PersonLight
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Identificador de la persona
      private long person_Id;
      // Nombre completo de la persona (Nombres y Apellidos)
      private string fullName;
      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      /// <summary>
      /// Identificador de la Persona
      /// </summary>
      public long Person_Id
      {
         get
         {
            return person_Id;
         }
         set
         {
            person_Id = value;
         }
      }

      /// <summary>
      /// Nombre completo de la persona (Nombres y Apellidos)
      /// </summary>
      public string FullName
      {
         get
         {
            return fullName;
         }
         set
         {
            fullName = value;
         }
      }
      #endregion Propiedades

      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public PersonLight()
      {
         this.person_Id = 0;
         this.fullName = string.Empty;
      }

      /// <summary>
      /// Constructor con parametros
      /// </summary>
      /// <param name="person_Id">Identificador de la persona</param>
      /// <param name="fullName">Nombre completo de la persona (Nombres y Apellidos)</param>
      public PersonLight(long person_Id, string fullName)
      {
         this.person_Id = person_Id;
         this.fullName = fullName;
      }
      #endregion Constructores

   }
}
