﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Telephone.cs                                                                      
 * Descripcion   : Entidad para manejar los datos de los telefonos                                        
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;

// NameSpace
namespace DirTel.Entities
{
   /// <summary>
   /// Entidad Telefonos
   /// </summary>
   public class Telephone
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Identificador del Telefono
      private long telephone_Id;
      // Identificador de la persona
      private long person_Id;
      // Identificador del tipo de telefono
      private TelephoneTypeCode telephone_Type;
      // Numero del telefono
      private string telephone_Number;
      // Notas adiconales al telefono
      private string notes;
      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      /// <summary>
      /// Identificador del Telefono
      /// </summary>
      public long Telephone_Id
      {
         get
         {
            return telephone_Id;
         }
         set
         {
            telephone_Id = value;
         }
      }

      /// <summary>
      /// Identificador de la Persona
      /// </summary>
      public long Person_Id
      {
         get
         {
            return person_Id;
         }
         set
         {
            person_Id = value;
         }
      }

      /// <summary>
      /// Identificador del tipo de telefono
      /// Hogar=1, Celular=2, Oficina=3
      /// </summary>
      public TelephoneTypeCode Telephone_Type
      {
         get
         {
            return telephone_Type;
         }
         set
         {
            telephone_Type = value;
         }
      }

      /// <summary>
      /// Numero del Telefono
      /// </summary>
      public string Telephone_Number
      {
         get
         {
            return telephone_Number;
         }
         set
         {
            telephone_Number = value;
         }
      }

      /// <summary>
      /// Notas adicionales al telefono
      /// </summary>
      public string Notes
      {
         get
         {
            return notes;
         }
         set
         {
            notes = value;
         }
      }

      #endregion Propiedades

      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public Telephone()
      {
         // Identificador del Telefono
         telephone_Id = 0;
         // Identificador de la persona
         person_Id = 0;
         // Identificador del tipo de telefono
         telephone_Type = TelephoneTypeCode.Home;
         // Numero del telefono
         telephone_Number = string.Empty;
         // Notas adiconales al telefono
         notes = string.Empty;
      }

      /// <summary>
      /// Constructor con parametros
      /// </summary>
      /// <param name="person_Id">Identificador de la Persona</param>
      /// <param name="telephone_Type">Tipo de telefono (1-Hogar, 2-Movil, 3-Oficina </param>
      /// <param name="telephone_Number">Numero del Telefono</param>
      /// <param name="notes">Notas adicionales al telefono</param>
      public Telephone(long person_Id, TelephoneTypeCode telephone_Type, string telephone_Number, string notes)
      {
         // Identificador de la persona
         this.person_Id = person_Id;
         // Identificador del tipo de telefono
         this.telephone_Type = telephone_Type;
         // Numero del telefono
         this.telephone_Number = telephone_Number;
         // Notas adiconales al telefono
         this.notes = notes;
      }

      #endregion Constructores
   }
}
