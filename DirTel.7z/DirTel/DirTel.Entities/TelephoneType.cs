﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : TelephoneType.cs                                                                     
 * Descripcion   : Entidad para manejar los tipos de telefonos                                                     
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                           
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;

// NameSpace
namespace DirTel.Entities
{
   // Enumeraciones
   #region Enumeraciones
   /// <summary>
   /// Identificadores de los Tipos de Telefonos
   /// </summary>
   public enum TelephoneTypeCode
   {
      /// <summary>
      /// Hogar o Fijo
      /// </summary>
      Home = 1,
      /// <summary>
      /// Celular o Movil
      /// </summary>
      Mobile,
      /// <summary>
      /// Oficina
      /// </summary>
      Work
   }

   #endregion Enumeraciones

   /// <summary>
   /// Entidaad para los tipos de telefonos
   /// </summary>
   public class TelephoneType
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Identificador del Codigo del tipo de telefono
      private TelephoneTypeCode value;
      // Descripcion o nombre del tipo de telefono 
      private string name;
      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      /// <summary>
      /// Identificador del Codigo del tipo de telefono
      /// </summary>
      public TelephoneTypeCode Value
      {
         get 
         { 
            return this.value; 
         }
         set
         { 
            this.value = value; 
         }
      }

      /// <summary>
      /// Descripcion o nombre del tipo de telefono 
      /// </summary>
      public string Name
      {
         get
         {
            return this.name;
         }
         set
         {
            this.name = value;
         }
      }
      #endregion Propiedades

      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public TelephoneType()
      {
         // Asignar valores por dfecto a los atributos
         this.value = TelephoneTypeCode.Home;
         this.name = TelephoneTypeCode.Home.ToString();
      }

      /// <summary>
      /// Constructor parametrizado
      /// </summary>
      /// <param name="value">Valor correspondiente al tipo de telefono</param>
      /// <param name="name">Descipcion o nombre correspondiente</param>
      public TelephoneType(TelephoneTypeCode value, string name)
      {
         // Asignar los valores a los atributos
         this.value = value;
         this.name = name;
      }
      #endregion Constructores
   }
}
