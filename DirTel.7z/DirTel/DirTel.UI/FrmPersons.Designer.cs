﻿namespace DirTel.UI
{
   partial class FrmPersons
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPersons));
         this.bndNavPersons = new System.Windows.Forms.BindingNavigator(this.components);
         this.bndSrcPersons = new System.Windows.Forms.BindingSource(this.components);
         this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
         this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
         this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSaveItems = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorAddNewTelephonesItem = new System.Windows.Forms.ToolStripButton();
         this.lblPersonId = new System.Windows.Forms.Label();
         this.txtPersonId = new System.Windows.Forms.TextBox();
         this.lblFirstName = new System.Windows.Forms.Label();
         this.lblLastName = new System.Windows.Forms.Label();
         this.LblBirthDay = new System.Windows.Forms.Label();
         this.lblSex = new System.Windows.Forms.Label();
         this.txtFirstName = new System.Windows.Forms.TextBox();
         this.txtLastName = new System.Windows.Forms.TextBox();
         this.dtpBirthDay = new System.Windows.Forms.DateTimePicker();
         this.radSexM = new System.Windows.Forms.RadioButton();
         this.radSexF = new System.Windows.Forms.RadioButton();
         this.txtSex = new System.Windows.Forms.TextBox();
         ((System.ComponentModel.ISupportInitialize)(this.bndNavPersons)).BeginInit();
         this.bndNavPersons.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.bndSrcPersons)).BeginInit();
         this.SuspendLayout();
         // 
         // bndNavPersons
         // 
         this.bndNavPersons.AddNewItem = null;
         this.bndNavPersons.BindingSource = this.bndSrcPersons;
         this.bndNavPersons.CountItem = this.bindingNavigatorCountItem;
         this.bndNavPersons.DeleteItem = null;
         this.bndNavPersons.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.bindingNavigatorSaveItems,
            this.bindingNavigatorAddNewTelephonesItem});
         this.bndNavPersons.Location = new System.Drawing.Point(0, 0);
         this.bndNavPersons.MoveFirstItem = null;
         this.bndNavPersons.MoveLastItem = null;
         this.bndNavPersons.MoveNextItem = null;
         this.bndNavPersons.MovePreviousItem = null;
         this.bndNavPersons.Name = "bndNavPersons";
         this.bndNavPersons.PositionItem = this.bindingNavigatorPositionItem;
         this.bndNavPersons.Size = new System.Drawing.Size(442, 25);
         this.bndNavPersons.TabIndex = 0;
         this.bndNavPersons.Text = "bndNavPerson";
         // 
         // bndSrcPersons
         // 
         this.bndSrcPersons.DataSource = typeof(DirTel.Entities.Person);
         this.bndSrcPersons.CurrentChanged += new System.EventHandler(this.bndSrcPersons_CurrentChanged);
         // 
         // bindingNavigatorCountItem
         // 
         this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
         this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
         this.bindingNavigatorCountItem.Text = "of {0}";
         this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
         // 
         // bindingNavigatorMoveFirstItem
         // 
         this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
         this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
         this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveFirstItem.Text = "Move first";
         this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
         // 
         // bindingNavigatorMovePreviousItem
         // 
         this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
         this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
         this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMovePreviousItem.Text = "Move previous";
         this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
         // 
         // bindingNavigatorSeparator
         // 
         this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
         this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorPositionItem
         // 
         this.bindingNavigatorPositionItem.AccessibleName = "Position";
         this.bindingNavigatorPositionItem.AutoSize = false;
         this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
         this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
         this.bindingNavigatorPositionItem.Text = "0";
         this.bindingNavigatorPositionItem.ToolTipText = "Current position";
         // 
         // bindingNavigatorSeparator1
         // 
         this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
         this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorMoveNextItem
         // 
         this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
         this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
         this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveNextItem.Text = "Move next";
         this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
         // 
         // bindingNavigatorMoveLastItem
         // 
         this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
         this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
         this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveLastItem.Text = "Move last";
         this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
         // 
         // bindingNavigatorSeparator2
         // 
         this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
         this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorAddNewItem
         // 
         this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
         this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
         this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorAddNewItem.Text = "Add new";
         this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
         // 
         // bindingNavigatorDeleteItem
         // 
         this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
         this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
         this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorDeleteItem.Text = "Delete";
         this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
         // 
         // bindingNavigatorSaveItems
         // 
         this.bindingNavigatorSaveItems.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorSaveItems.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorSaveItems.Image")));
         this.bindingNavigatorSaveItems.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.bindingNavigatorSaveItems.Name = "bindingNavigatorSaveItems";
         this.bindingNavigatorSaveItems.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorSaveItems.Text = "SaveItems";
         this.bindingNavigatorSaveItems.ToolTipText = "Save Items";
         this.bindingNavigatorSaveItems.Click += new System.EventHandler(this.bindingNavigatorSaveItems_Click);
         // 
         // bindingNavigatorAddNewTelephonesItem
         // 
         this.bindingNavigatorAddNewTelephonesItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorAddNewTelephonesItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewTelephonesItem.Image")));
         this.bindingNavigatorAddNewTelephonesItem.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.bindingNavigatorAddNewTelephonesItem.Name = "bindingNavigatorAddNewTelephonesItem";
         this.bindingNavigatorAddNewTelephonesItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorAddNewTelephonesItem.Text = "AddNewTelephones";
         this.bindingNavigatorAddNewTelephonesItem.ToolTipText = "Add New Telephones";
         this.bindingNavigatorAddNewTelephonesItem.Click += new System.EventHandler(this.bindingNavigatorAddNewTelephonesItem_Click);
         // 
         // lblPersonId
         // 
         this.lblPersonId.AutoSize = true;
         this.lblPersonId.Location = new System.Drawing.Point(68, 40);
         this.lblPersonId.Name = "lblPersonId";
         this.lblPersonId.Size = new System.Drawing.Size(58, 13);
         this.lblPersonId.TabIndex = 1;
         this.lblPersonId.Text = "Person Id :";
         // 
         // txtPersonId
         // 
         this.txtPersonId.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bndSrcPersons, "Person_Id", true));
         this.txtPersonId.Location = new System.Drawing.Point(132, 37);
         this.txtPersonId.Name = "txtPersonId";
         this.txtPersonId.ReadOnly = true;
         this.txtPersonId.Size = new System.Drawing.Size(100, 20);
         this.txtPersonId.TabIndex = 2;
         // 
         // lblFirstName
         // 
         this.lblFirstName.AutoSize = true;
         this.lblFirstName.Location = new System.Drawing.Point(71, 66);
         this.lblFirstName.Name = "lblFirstName";
         this.lblFirstName.Size = new System.Drawing.Size(55, 13);
         this.lblFirstName.TabIndex = 3;
         this.lblFirstName.Text = "Nombres :";
         // 
         // lblLastName
         // 
         this.lblLastName.AutoSize = true;
         this.lblLastName.Location = new System.Drawing.Point(71, 92);
         this.lblLastName.Name = "lblLastName";
         this.lblLastName.Size = new System.Drawing.Size(55, 13);
         this.lblLastName.TabIndex = 5;
         this.lblLastName.Text = "Apellidos :";
         // 
         // LblBirthDay
         // 
         this.LblBirthDay.AutoSize = true;
         this.LblBirthDay.Location = new System.Drawing.Point(12, 119);
         this.LblBirthDay.Name = "LblBirthDay";
         this.LblBirthDay.Size = new System.Drawing.Size(114, 13);
         this.LblBirthDay.TabIndex = 7;
         this.LblBirthDay.Text = "Fecha de Nacimiento :";
         // 
         // lblSex
         // 
         this.lblSex.AutoSize = true;
         this.lblSex.Location = new System.Drawing.Point(89, 143);
         this.lblSex.Name = "lblSex";
         this.lblSex.Size = new System.Drawing.Size(37, 13);
         this.lblSex.TabIndex = 9;
         this.lblSex.Text = "Sexo :";
         // 
         // txtFirstName
         // 
         this.txtFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bndSrcPersons, "FirstName", true));
         this.txtFirstName.Location = new System.Drawing.Point(132, 63);
         this.txtFirstName.MaxLength = 40;
         this.txtFirstName.Name = "txtFirstName";
         this.txtFirstName.Size = new System.Drawing.Size(300, 20);
         this.txtFirstName.TabIndex = 4;
         // 
         // txtLastName
         // 
         this.txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bndSrcPersons, "LastName", true));
         this.txtLastName.Location = new System.Drawing.Point(132, 89);
         this.txtLastName.Name = "txtLastName";
         this.txtLastName.Size = new System.Drawing.Size(300, 20);
         this.txtLastName.TabIndex = 6;
         // 
         // dtpBirthDay
         // 
         this.dtpBirthDay.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bndSrcPersons, "BirthDay", true));
         this.dtpBirthDay.Location = new System.Drawing.Point(132, 115);
         this.dtpBirthDay.Name = "dtpBirthDay";
         this.dtpBirthDay.Size = new System.Drawing.Size(200, 20);
         this.dtpBirthDay.TabIndex = 8;
         // 
         // radSexM
         // 
         this.radSexM.AutoSize = true;
         this.radSexM.Checked = true;
         this.radSexM.Location = new System.Drawing.Point(132, 141);
         this.radSexM.Name = "radSexM";
         this.radSexM.Size = new System.Drawing.Size(73, 17);
         this.radSexM.TabIndex = 10;
         this.radSexM.TabStop = true;
         this.radSexM.Text = "Masculino";
         this.radSexM.UseVisualStyleBackColor = true;
         this.radSexM.Click += new System.EventHandler(this.radSex_Click);
         // 
         // radSexF
         // 
         this.radSexF.AutoSize = true;
         this.radSexF.Location = new System.Drawing.Point(223, 141);
         this.radSexF.Name = "radSexF";
         this.radSexF.Size = new System.Drawing.Size(71, 17);
         this.radSexF.TabIndex = 11;
         this.radSexF.Text = "Femenino";
         this.radSexF.UseVisualStyleBackColor = true;
         this.radSexF.Click += new System.EventHandler(this.radSex_Click);
         // 
         // txtSex
         // 
         this.txtSex.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bndSrcPersons, "Sex", true));
         this.txtSex.Location = new System.Drawing.Point(300, 140);
         this.txtSex.Name = "txtSex";
         this.txtSex.Size = new System.Drawing.Size(32, 20);
         this.txtSex.TabIndex = 12;
         this.txtSex.Visible = false;
         // 
         // FrmPersons
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
         this.ClientSize = new System.Drawing.Size(442, 166);
         this.Controls.Add(this.txtSex);
         this.Controls.Add(this.radSexF);
         this.Controls.Add(this.radSexM);
         this.Controls.Add(this.dtpBirthDay);
         this.Controls.Add(this.txtLastName);
         this.Controls.Add(this.txtFirstName);
         this.Controls.Add(this.lblSex);
         this.Controls.Add(this.LblBirthDay);
         this.Controls.Add(this.lblLastName);
         this.Controls.Add(this.lblFirstName);
         this.Controls.Add(this.txtPersonId);
         this.Controls.Add(this.lblPersonId);
         this.Controls.Add(this.bndNavPersons);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FrmPersons";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "Personas";
         this.Load += new System.EventHandler(this.FrmPersons_Load);
         ((System.ComponentModel.ISupportInitialize)(this.bndNavPersons)).EndInit();
         this.bndNavPersons.ResumeLayout(false);
         this.bndNavPersons.PerformLayout();
         ((System.ComponentModel.ISupportInitialize)(this.bndSrcPersons)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.BindingNavigator bndNavPersons;
      private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
      private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
      private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
      private System.Windows.Forms.BindingSource bndSrcPersons;
      private System.Windows.Forms.Label lblPersonId;
      private System.Windows.Forms.TextBox txtPersonId;
      private System.Windows.Forms.Label lblFirstName;
      private System.Windows.Forms.Label lblLastName;
      private System.Windows.Forms.Label LblBirthDay;
      private System.Windows.Forms.Label lblSex;
      private System.Windows.Forms.TextBox txtFirstName;
      private System.Windows.Forms.TextBox txtLastName;
      private System.Windows.Forms.DateTimePicker dtpBirthDay;
      private System.Windows.Forms.RadioButton radSexM;
      private System.Windows.Forms.RadioButton radSexF;
      private System.Windows.Forms.ToolStripButton bindingNavigatorSaveItems;
      private System.Windows.Forms.TextBox txtSex;
      private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewTelephonesItem;
   }
}