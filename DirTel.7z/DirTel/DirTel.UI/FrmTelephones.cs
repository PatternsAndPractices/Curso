﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        :  FrmTelephones.cs                                                                    
 * Descripcion   : Fomrulario para administrar los datos de los telefonos
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 23-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 23-May-2010   Jucer          1 - Version Inicial                                                     
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
// Librerias de DirTel
using DirTel.BL;
using DirTel.Entities;

// NameSpace
namespace DirTel.UI
{
   /// <summary>
   /// Formulario par aadministrar los datos de los telefonos
   /// </summary>
   public partial class FrmTelephones : Form
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Identificador de la persona que se referencia desde FrmPerson o desde el Menu
      private long person_Id;

      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      /// <summary>
      /// Identificador de la persona referenciado desde FrmPerson
      /// si no se agina valor, su asignacion sera cero (0) por defecto
      /// </summary>
      public long Person_Id
      {
         get
         {
            return person_Id;
         }
         set
         {
            person_Id = value;
         }
      }
      #endregion Propiedades

      // Constructores
      #region Constructores
      /// <summary>
      /// Construcor por defecto
      /// </summary>
      public FrmTelephones()
      {
         InitializeComponent();

         // Asignar cero (0) por defecto al identificador de la persona
         this.person_Id = 0;
      }
      #endregion Constructores


      // Metodos
      #region Metodos

      // Privados
      #region Privados
      /// <summary>
      /// Cargar el formulario
      /// </summary>
      /// <param name="sender">Form</param>
      /// <param name="e">Load</param>
      private void FrmTelephones_Load(object sender, EventArgs e)
      {
         // Cargar el combo con los datos de las personas
         this.LoadPersons(this.cmbPersons);

         // Enlazar el PersonId
         this.BindPersonId(this.txtPersonId, this.cmbPersons);

         // Desactivar la generacion automatica de las columnas para la Grid
         this.dgvTelephones.AutoGenerateColumns = false;

         // Inicializar las columnaqs de la Grid
         this.InitializeColumnnsTelephones();

         // Validar el identificador de la persona
         if (this.person_Id != 0)
         {
            // Seleccionar el valor del combo correspondiente
            cmbPersons.SelectedValue = this.person_Id;
         }

         // Obtener los datos de los telefonos
         this.LoadTelephones(this.cmbPersons, this.dgvTelephones);
         
      }


      /// <summary>
      /// Ejecuta el cambio de registro al seleccionar un valor del combo
      /// </summary>
      /// <param name="sender">cmbPersons</param>
      /// <param name="e">SelectionChangeCommitted</param>
      private void cmbPersons_SelectionChangeCommitted(object sender, EventArgs e)
      {
         // Varialbe para referencia el combo
         ComboBox cmb = (ComboBox)sender;

         // Cargar los datos de los telefonos
         this.LoadTelephones(cmb, this.dgvTelephones);
      }

      /// <summary>
      /// Controlar el borrado del registro
      /// </summary>
      /// <param name="sender">Binding Navigator</param>
      /// <param name="e">DeleteItem</param>
      private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
      {
         // Validar que existan registros para borrar
         if (dgvTelephones.RowCount > 0)
         {

            // Preguntar si en realidad lo desea eliminar
            DialogResult dlgResult = MessageBox.Show("Esta seguro de eliminar este registro?", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            // Validar la respuesta
            if (dlgResult == DialogResult.Yes)
            {
               // Obtener el registro activo
               Telephone telephone = (Telephone)dgvTelephones.CurrentRow.DataBoundItem;

               // Eliminar el registro
               this.DeleteTelephone(telephone.Telephone_Id);

               // Eliminar el registro de la grid
               BindingSource bndSrc = (BindingSource)dgvTelephones.DataSource;
               bndSrc.RemoveCurrent();
            }
         }
      }

      /// <summary>
      /// Adiciona un registro a los datos de los telefonos
      /// </summary>
      /// <param name="sender">Binding Navigator</param>
      /// <param name="e">AddNewItem</param>
      private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
      {
         // Enlazar el Binding Source
         BindingSource bndSrc = (BindingSource)dgvTelephones.DataSource;

         // Instanciar una nuevo objeto de tipo Telephone
         Telephone telephone = new Telephone();

         // Obtener los datos de la persona seleccionada
         PersonLight personLight = (PersonLight)cmbPersons.SelectedItem;

         // asignar el Id de la persona
         telephone.Person_Id = personLight.Person_Id;
         // Asignar por defecto un telefono vacio
         telephone.Telephone_Number = String.Empty;

         // Adicionar un nuevo registro al Binding Source
         bndSrc.Add(telephone);

      }

      /// <summary>
      /// Elimina el registro del telefono asociado
      /// </summary>
      /// <param name="telephone_Id">Identificador del telefono</param>
      private void DeleteTelephone(long telephone_Id)
      {
         // Instanciar objeto de logica de negocio
         TelephoneBL telephoneBL = new TelephoneBL();

         // Llamar al metodo de eliminar
         telephoneBL.DeleteTelephone(telephone_Id);
      }

      /// <summary>
      /// Grabar los cambios
      /// </summary>
      /// <param name="sender">Binding Navigator</param>
      /// <param name="e">SaveItems</param>
      private void bindingNavigatorSaveItems_Click(object sender, EventArgs e)
      {
         // Cambiar el foco al identificador de la persona
         txtPersonId.Focus();

         // Obtener la cantidad de filas
         int countRows = dgvTelephones.RowCount;

         // Validar la cantidad de filas
         if (countRows > 0)
         {
            // Objeto para referenciar el telefono activo
            Telephone telephoneCurrent = null;

            // Ciclo para recorer la Grid
            for (int i = 0; i < countRows; i++)
            {
               // Seleccionar y obtener la fila
               DataGridViewRow dgvRow = dgvTelephones.Rows[i];

               // Obtener los datos del telefono actual
               telephoneCurrent = (Telephone)dgvRow.DataBoundItem;

               // Validar la fila actual
               if (telephoneCurrent.Telephone_Id.Equals(0))
               {
                  // Insertar un nuevo registro
                  this.CreateTelephone(telephoneCurrent);
               }
               else
               {
                  // Actualizar el registro
                  this.UpdateTelephone(telephoneCurrent);
               }
            }

            // Mostrar mensaje de datos actualizados
            MessageBox.Show("Datos Actualizados", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
         }
      }

      /// <summary>
      /// Crear un nuevo resgistro
      /// </summary>
      /// <param name="telephoneCurrent">Datos del Registro a crear</param>
      private void CreateTelephone(Telephone telephoneCurrent)
      {
         // Instanciar objeto de logica de Negocio
         TelephoneBL telephoneBL = new TelephoneBL();

         // Insertar el registro y retornar el Id
         long telephoneId = telephoneBL.CreateTelephone(telephoneCurrent);

         // Asignar el identificaro del telefono
         telephoneCurrent.Telephone_Id = telephoneId;

      }

      /// <summary>
      /// Actualiza el registro actual
      /// </summary>
      /// <param name="telephoneCurrent">Datos del registro a actualizar</param>
      private void UpdateTelephone(Telephone telephoneCurrent)
      {
         // Instanciar objeto de logica de Negocio
         TelephoneBL telephoneBL = new TelephoneBL();

         // Insertar el registro y retornar el Id
         telephoneBL.UpdateTelephone(telephoneCurrent);

      }


      /// <summary>
      /// Cargar los datos de los telefonos según el valor de la persona
      /// </summary>
      /// <param name="comboBox">Combo de personas</param>
      /// <param name="dataGridView">Grid de telefonos</param>
      private void LoadTelephones(ComboBox comboBox, DataGridView dataGridView)
      {
         // Obtener los datos de la persona seleccionada
         PersonLight personLight = (PersonLight)comboBox.SelectedItem;

         // Fuente de datos enlazada
         BindingSource bndSrc = new BindingSource();

         // Obtener el Id de la persona validando si hay datos
         long person_Id = (personLight == null)? 0 : personLight.Person_Id;

         // Obtener los Telefonos asociados a la persona
         bndSrc.DataSource = this.GetTelephones(person_Id);

         // Asignar la fuente de datos
         dataGridView.DataSource = bndSrc;

         // Asignar el origen de datos del Navegador a el correspondiente de la Grid
         bndNavTelephones.BindingSource = bndSrc;

      }

      /// <summary>
      /// Obtener la lista de telefonos segun la persona
      /// </summary>
      /// <param name="person_Id">Identificador de la persona</param>
      /// <returns>Lista de telefonos de la persona</returns>
      private IList<Telephone> GetTelephones(long person_Id)
      {
         // Instanciar el objeto de negocio
         TelephoneBL telephoneBL = new TelephoneBL();

         // Obtener la lista de telefonos por persona
         IList<Telephone> lstTelephones = telephoneBL.ReadTelephonesByPersonId(person_Id);

         // Retornar la lista
         return lstTelephones;
      }


      /// <summary>
      /// Inicializa las columnas de la grid
      /// </summary>
      private void InitializeColumnnsTelephones()
      {
         // Asignar las propiedades a enlazar de las columnas con la entidad Telephone
         this.ColumnTelephoneId.DataPropertyName = "Telephone_Id";
         this.ColumnPersonId.DataPropertyName = "Person_Id";
         this.ColumnTelephoneType.DataPropertyName = "Telephone_Type";
         this.ColumnTelephoneNumber.DataPropertyName = "Telephone_Number";
         this.ColumnTelephoneNotes.DataPropertyName = "Notes";

         // Llenar el combo Box de Tipos de telefonos de Telephone_Type
         this.ColumnTelephoneType.DataSource = this.GetTelephoneTypes();

         // Enlazar las propiedades de la entidad TelephoneType con los de la columna
         this.ColumnTelephoneType.DisplayMember = "Name";
         this.ColumnTelephoneType.ValueMember = "Value";
      }


      /// <summary>
      /// Obtiene la lista de tipos de telefonos
      /// </summary>
      /// <returns>Lista de tipos de telefonos (Codigo, Nombre)</returns>
      private IList<TelephoneType> GetTelephoneTypes()
      {
         // Variable para la lista de Tipos de telefonos
         IList<TelephoneType> lstTelephoneTypes = new List<TelephoneType>();

         // Obtener los nombres de la enumeracion
         string[] arrTelephoneTypeNames = Enum.GetNames(typeof(TelephoneTypeCode));

         // Obtener los codigos de la enumeracion
         int[] arrTelephoneTypeCodes = (int[])Enum.GetValues(typeof(TelephoneTypeCode));

         // Obtener la longitud del arreglo de codigos
         int lenTelephoneTypes = arrTelephoneTypeCodes.Length;

         // Recorrer los arreglos, obtener los valores y adicionarlos a la lista
         for (int i = 0; i < lenTelephoneTypes; i++)
         {
            // Variable para el tipo de telefono
            TelephoneType telephoneType = new TelephoneType();

            // Asignar los valores
            telephoneType.Value = (TelephoneTypeCode)arrTelephoneTypeCodes[i];
            telephoneType.Name = arrTelephoneTypeNames[i];

            // Adicionar el tipo de telefono a la lista
            lstTelephoneTypes.Add(telephoneType);
         }

         // Retornar la lista de Tipos de telefonos
         return lstTelephoneTypes;

      }

      /// <summary>
      /// Enlazar el campo Id con el combo
      /// </summary>
      /// <param name="textBox">Texto del Id</param>
      /// <param name="comboBox">combo a enlazar</param>
      private void BindPersonId(TextBox textBox, ComboBox comboBox)
      {
         // Objeto para enlazar las propiedades
         Binding bnd = new Binding("Text", comboBox.DataSource, "Person_Id");
         // Enlazar el valor al control de texto
         textBox.DataBindings.Add(bnd);

      }


      /// <summary>
      /// Cargar los datos de las personas
      /// </summary>
      /// <param name="cmb">Combo donde se asignan los datos</param>
      public void LoadPersons(ComboBox cmb)
      {
         // Instanciar logica de Negocio
         PersonBL personBL = new PersonBL();

         // Obtener la lista de las personas
         IList<PersonLight> lstPersonLight = personBL.ReadAllPersonsLight();

         // Validar si hay personas
         if (lstPersonLight.Count == 0)
         {
            // Mostrar el Mensaje de advertencia que no hay personas
            MessageBox.Show("Adicione primero registros de personas", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            // Deshabilitar los botones personalizados del Navigator
            this.bindingNavigatorAddNewItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorSaveItems.Enabled = false;
         }

         // Asignar la lista a la fuente de datos del combo
         cmb.DataSource = lstPersonLight;

         // Asignar las propiedades del Combo
         cmb.DisplayMember = "FullName";
         cmb.ValueMember = "Person_Id";

      }

      #endregion Privados

      #endregion Metodos










   }
}
