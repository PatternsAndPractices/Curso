﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Program                                                                                   
 * Descripcion   : Clase Inicial del Proyecto                                                      
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Windows.Forms;


// NameSpace
namespace DirTel.UI
{
   /// <summary>
   /// Clase inicial del proyecto
   /// </summary>
   static class Program
   {
      /// <summary>
      /// Punto principal de entrada a la aplicacion
      /// </summary>
      [STAThread]
      static void Main()
      {
         //Inicializar los componentes visuales 
         Application.EnableVisualStyles();
         Application.SetCompatibleTextRenderingDefault(false);

         // Ejecutar el llamado al formulario Principal
         //Application.Run(new FrmPersons());
         Application.Run(new MDIMain());
      }
   }
}
