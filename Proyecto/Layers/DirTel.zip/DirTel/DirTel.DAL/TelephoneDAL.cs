﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : TelephoneDAL.cs  
 * Descripcion   : Permite acceder a los datos de los telefonos
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 23-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 23-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;
// Librerias de ORACLE
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
// Librerias de SQLHelper
using EandT.Framework.Base.Data;
// Librerias de DirTel
using DirTel.Entities;

// NameSpace
namespace DirTel.DAL
{
   /// <summary>
   /// Clase para acceder a los datos de la entidad Telefonos
   /// </summary>
   public class TelephoneDAL
   {

      // Campos o Atributos
      #region Campos o Atributos
      // Cadena de conexion a la Base de datos
      private string strCnx;
      // Variable para manejar el enlace a la base de datos
      private DataBase db;
      // Variable para manejar la conexion a la base de datos
      private IDbConnection cnx;

      #endregion Campos o Atributos

      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public TelephoneDAL()
      {
         // Incicializar la cadena de conexion
         strCnx = ConfigurationManager.ConnectionStrings["DirTelCnx"].ConnectionString;
      }
      #endregion Constructores

      // Metodos
      #region Metodos

      // Publicos
      #region Publicos
      /// <summary>
      /// Inserta los datos del telefono
      /// </summary>
      /// <param name="telephone">Datos del Telefono</param>
      /// <returns>Identificador del Telefono</returns>
      public long CreateTelephone(Telephone telephone)
      {
         // Variable para retornar el id del telefono
         long telephone_Id = 0;

         // Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_TELEPHONES_PKG.CreateTelephone";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Person_Id", telephone.Person_Id, DbType.Int64);
         db.AddInParameter(cmd, "pm_Telephone_Type", Convert.ToInt32(telephone.Telephone_Type), DbType.Int32);
         db.AddInParameter(cmd, "pm_Telephone_Number", telephone.Telephone_Number, DbType.String);
         db.AddInParameter(cmd, "pm_Notes", telephone.Notes, DbType.String);
         // Adicionar el parametro de salida 
         db.AddOutParameter(cmd, "pm_Telephone_Id", null, DbType.Int64);

         //Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Referencia el parametro de salida para el Id del telefono
         OracleParameter outTelephone_Id = cmd.Parameters[db.ParameterToken() + "pm_Telephone_Id"] as OracleParameter;

         // Obtener el valor del parametro
         telephone_Id = Convert.ToInt64(outTelephone_Id.Value);

         //Cerrar la conexion
         db.CloseConnection(cnx);

         //retornar el valor 
         return telephone_Id;

      }

      /// <summary>
      /// Obtener todos los telefonos de una persona
      /// </summary>
      /// <param name="person_Id">Identificador de la persona</param>
      /// <returns>La Lista de Telefonos</returns>
      public IList<Telephone> ReadTelephonesByPersonId(long person_Id)
      {
         // Crear la lista para retornar los datos
         IList<Telephone> lstTelephones = new List<Telephone>();

         // Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando especial para ORACLE
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_TELEPHONES_PKG.ReadTelephonesByPersonId";
         cmd.CommandType = CommandType.StoredProcedure;

         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Person_Id", person_Id, DbType.Int64);

         // Crear el Parametro enlazado al Cursor Referenciado
         OracleParameter paramRefCursor = db.AddCommandRefCurParameter(((OracleCommand)cmd), "cur_Telephones", ParameterDirection.Output, null);

         // Ejecutar el query
         db.ExecuteNonQuery(cnx, cmd);

         // Obtener el Cursor Referenciado
         OracleRefCursor refCur = (OracleRefCursor)paramRefCursor.Value;
         // Obtener el DataReader desde el cursor referenciado
         OracleDataReader dr = refCur.GetDataReader();

         // Ciclo para Recorer los datos
         while (dr.Read())
         {
            // Variable Person para obtener los datos
            Telephone telephone = new Telephone();

            // Leer los valores
            telephone.Telephone_Id = Convert.ToInt64(dr["Telephone_Id"].ToString());
            telephone.Person_Id = Convert.ToInt64(dr["Person_Id"].ToString());
            telephone.Telephone_Type = (TelephoneTypeCode)Convert.ToInt32(dr["Telephone_Type"].ToString());
            telephone.Telephone_Number = dr["Telephone_Number"].ToString();
            telephone.Notes = dr["Notes"].ToString();


            // Adicionar el Valor a la lista
            lstTelephones.Add(telephone);
         }

         // Cerar la Conexion
         db.CloseConnection(cnx);

         // retornar la lista
         return lstTelephones;
      }

      /// <summary>
      /// Obtener todos los datos de los Telefonos
      /// </summary>
      /// <returns>Lista con los datos de los telefonos</returns>
      public IList<Telephone> ReadAllTelephones()
      {
         // Crear la lista para retornar los datos
         IList<Telephone> lstTelephones = new List<Telephone>();

         // Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando especial para ORACLE
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_TELEPHONES_PKG.ReadAllTelephones";
         cmd.CommandType = CommandType.StoredProcedure;

         // Crear el Parametro enlazado al Cursor Referenciado
         OracleParameter paramRefCursor = db.AddCommandRefCurParameter(((OracleCommand)cmd), "cur_Telephones", ParameterDirection.Output, null);

         // Ejecutar el query
         db.ExecuteNonQuery(cnx, cmd);

         // Obtener el Cursor Referenciado
         OracleRefCursor refCur = (OracleRefCursor)paramRefCursor.Value;
         // Obtener el DataReader desde el cursor referenciado
         OracleDataReader dr = refCur.GetDataReader();

         // Ciclo para Recorer los datos
         while (dr.Read())
         {
            // Variable Person para obtener los datos
            Telephone telephone = new Telephone();

            // Leer los valores
            telephone.Telephone_Id = Convert.ToInt64(dr["Telephone_Id"].ToString());
            telephone.Person_Id = Convert.ToInt64(dr["Person_Id"].ToString());
            telephone.Telephone_Type = (TelephoneTypeCode)Convert.ToInt32(dr["Telephone_Type"].ToString());
            telephone.Telephone_Number = dr["Telephone_Number"].ToString();
            telephone.Notes = dr["Notes"].ToString();

            // Adicionar el Valor a la lista
            lstTelephones.Add(telephone);
         }

         // Cerar la Conexion
         db.CloseConnection(cnx);

         // retornar la lista
         return lstTelephones;
      }

      /// <summary>
      /// Borrar el Registro de la tabla segun el Id
      /// </summary>
      /// <param name="telephone_Id">Id a borrar</param>
      public void DeleteTelephone(long telephone_Id)
      {
         // Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_TELEPHONES_PKG.DeleteTelephone";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Telephone_Id", telephone_Id, DbType.Int64);

         // Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Cerrar la conexion
         db.CloseConnection(cnx);

      }

      /// <summary>
      /// Actualiza los datos del telefono
      /// </summary>
      /// <param name="telephone">Datos del telefono</param>
      public void UpdateTelephone(Telephone telephone)
      {
         // Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_TELEPHONES_PKG.UpdateTelephone";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Telephone_Id", telephone.Telephone_Id, DbType.Int64);
         db.AddInParameter(cmd, "pm_Person_Id", telephone.Person_Id, DbType.Int64);
         db.AddInParameter(cmd, "pm_Telephone_Type", Convert.ToInt32(telephone.Telephone_Type), DbType.Int32);
         db.AddInParameter(cmd, "pm_Telephone_Number", telephone.Telephone_Number, DbType.String);
         db.AddInParameter(cmd, "pm_Notes", telephone.Notes, DbType.String);

         // Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Cerrar la conexion
         db.CloseConnection(cnx);

      }

      #endregion Publicos

      #endregion Metodos
   }
}
