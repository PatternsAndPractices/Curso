﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : FrmPerson.cs                                                                      
 * Descripcion   : Formulario para manejar los datos de la entidad Person                                                      
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
// Librerias DirTel
using DirTel.BL;
using DirTel.Entities;

// NameSpace
namespace DirTel.UI
{
   /// <summary>
   /// Formulario para el manejo de los datos de las Personas
   /// </summary>
   public partial class FrmPersons : Form
   {
      // Enumeraciones
      #region Enumeraciones
      // Enumeracion para validar cuando activar o desactivar los campos
      private enum ActiveField
      {
         Enabled,
         Disabled
      }
      #endregion Enumeraciones

      // Constructores
      #region Constructores
      /// <summary>
      /// Construcor por defecto
      /// </summary>
      public FrmPersons()
      {
         InitializeComponent();
      }
      #endregion Constructores

      // Metodos
      #region Metodos

      // Privados
      #region Privados

      // Formulario
      #region Formulario
      /// <summary>
      /// Cargar el formulario obteniendo los datos y desactivando los controles
      /// </summary>
      /// <param name="sender">Form</param>
      /// <param name="e">Load Event</param>
      private void FrmPersons_Load(object sender, EventArgs e)
      {
         //Obtener los datos de todas las personas
         this.ReadAllPersons();

         //Validar si no existen Registros en el BindingSource Desactivar los Controles
         if (bndSrcPersons.List.Count == 0)
         {
            //Desactivar los controles
            this.ActivateFields(ActiveField.Disabled);
         }
      }

      #endregion Formulario

      // BindingNavigator
      #region BindingNavigator
      /// <summary>
      /// Ir al Primer Registro
      /// </summary>
      /// <param name="sender">Binding Source</param>
      /// <param name="e">MoveFirstItem Click</param>
      private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
      {
         bndSrcPersons.MoveFirst();
      }

      /// <summary>
      /// Ir al Registro Anterior
      /// </summary>
      /// <param name="sender">Binding Source</param>
      /// <param name="e">MovePreviousItem Click</param>
      private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
      {
         bndSrcPersons.MovePrevious();
      }

      /// <summary>
      /// Ir al Registro Siguiente
      /// </summary>
      /// <param name="sender">Binding Source</param>
      /// f<param name="e">MoveNextItem Click</param>
      private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
      {
         bndSrcPersons.MoveNext();
      }

      /// <summary>
      /// Ir al Ultimo Registro
      /// </summary>
      /// <param name="sender">Binding Source</param>
      /// <param name="e">MoveLastItem Click</param>
      private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
      {
         bndSrcPersons.MoveLast();
      }

      /// <summary>
      /// Adicionar un registro
      /// </summary>
      /// <param name="sender">AddNewItem</param>
      /// <param name="e">Click Event</param>
      private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
      {
         //Poner el Foco en el campo del Id
         txtPersonId.Focus();

         // Validar si no existen Registros en el BindingSource Activar los Controles
         if (bndSrcPersons.List.Count == 0)
         {
            // Activar los campos
            this.ActivateFields(ActiveField.Enabled);
         }

         // Crear un objeto person en blanco
         Person person = new Person();

         // Adicionar un Nuevo Registro
         bndSrcPersons.Add(person);
         bndSrcPersons.MoveLast();
      }

      /// <summary>
      /// Eliminar el Registro Activo
      /// </summary>
      /// <param name="sender">DeleteItem</param>
      /// <param name="e">Click Event</param>
      private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
      {
         // Poner el Foco en el campo del Id
         txtPersonId.Focus();

         // Validar si el Id de la persona no es vacio
         if (!txtPersonId.Text.Trim().Equals(string.Empty))
         {
            // Preguntar si en realidad lo desea eliminar
            DialogResult dlgResult = MessageBox.Show("Esta seguro de eliminar este registro?", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            // Validar si la respuesta fue positiva
            if (dlgResult == DialogResult.Yes)
            {
               // Borrar el Registro
               DeletePerson();

               // Validar si no existen Registros en el BindingSource DesActivar los Controles
               if (bndSrcPersons.List.Count == 0)
               {
                  // Activar los campos
                  this.ActivateFields(ActiveField.Disabled);
               }
            }
         }
      }

      /// <summary>
      /// Actualizar los datos de la tabla con los items del BindingSource
      /// </summary>
      /// <param name="sender">BindingSource</param>
      /// <param name="e">Click Event</param>
      private void bindingNavigatorSaveItems_Click(object sender, EventArgs e)
      {
         // Poner el Foco en el campo del Id
         txtPersonId.Focus();

         // Obtener La cantidad de datos
         int countPersons = bndSrcPersons.List.Count;

         // Variable para Obtner los datos de la persona
         Person person = null;

         // Ciclo Para Recorrer los datos 
         for (int i = 0; i < countPersons; i++)
         {
            // Obtener los datos de la lista
            person = bndSrcPersons.List[i] as Person;

            // Validar la accion del registro
            if (person.Person_Id == 0)
            {
               // Crear la Persona
               this.CreatePerson(person);
               // Actualizar el identificador en el formulario
               txtPersonId.Text = person.Person_Id.ToString();
            }
            else
            {
               //Actualizar los datos Modificados
               this.UpdatePerson(person);
            }

         }

      }

      /// <summary>
      /// Administrar los datos de los telefonos de la persona
      /// </summary>
      /// <param name="sender">BindingSource</param>
      /// <param name="e">Click Event</param>
      private void bindingNavigatorAddNewTelephonesItem_Click(object sender, EventArgs e)
      {
         // Poner el Foco en el campo del Id
         txtPersonId.Focus();

         // Validar si el Id de la persona no es vacio
         if (!txtPersonId.Text.Trim().Equals(string.Empty))
         {
            // Obtenr el Id de la persona actual
            long person_Id = Convert.ToInt64(this.txtPersonId.Text);

            // Instanciar un nuevo formulario de Telefonos
            FrmTelephones frmTelephones = new FrmTelephones();

            // Asignar el Identificador de la persona al formulario
            frmTelephones.Person_Id = person_Id;

            // Asignar el formulario padre
            frmTelephones.MdiParent = this.MdiParent;

            // Mostrar el formulario
            frmTelephones.Show();

         }
      }

      #endregion BindingNavigator

      // BindingSource
      #region BindingSource
      /// <summary>
      /// Controlar el Cambio de registro en el formulario
      /// </summary>
      /// <param name="sender">BindingSource</param>
      /// <param name="e">CurrentChanged Event</param>
      private void bndSrcPersons_CurrentChanged(object sender, EventArgs e)
      {
         // Obtener los datos de la persona actual
         Person person = bndSrcPersons.Current as Person;

         // Validar si hay personas
         if (person != null)
         {

            // Validar si el Sexo 
            if (person.Sex == 'M')
            {
               // Activar Masculino
               this.radSexM.Checked = true;
            }
            else
            {
               // Activar Femenino
               this.radSexF.Checked = true;
            }
         }

      }

      #endregion BindingSource

      // RadSex
      #region RadSex
      /// <summary>
      /// Asignar el sexo Masculino (M) o Femenino (F) al campo oculto SEX
      /// </summary>
      /// <param name="sender">RadioButton</param>
      /// <param name="e">Click Event</param>
      private void radSex_Click(object sender, EventArgs e)
      {
         // Obtener el control
         RadioButton radSex = sender as RadioButton;

         // Asignar el valor por defecto 
         char sex = 'M';

         // Validar el control
         if (radSex.Text.Equals("Femenino"))
         {
            sex = 'F';
         }

         // Obtener una refrencia al registro actual
         Person person = bndSrcPersons.Current as Person;
         // Cambiar el Sexo
         person.Sex = sex;

         // Asignar el valor al campo de texto
         txtSex.Text = person.Sex.ToString();
      }

      #endregion RadSex

      // Utilities
      #region Fields
      /// <summary>
      /// Activa o desactiva los controles del Formulario
      /// </summary>
      /// <param name="activeField">Enabled/Disabled</param>
      private void ActivateFields(ActiveField activeField)
      {
         // Variable para controlar el cambio
         bool enabled = true;
         // Validar si el cambio es desactivar los controles
         if (activeField == ActiveField.Disabled)
         {
            // Asignar desactivar los controles
            enabled = false;
         }
         // Desactivar los controles
         txtFirstName.Enabled = enabled;
         txtLastName.Enabled = enabled;
         dtpBirthDay.Enabled = enabled;
         radSexM.Enabled = enabled;
         radSexF.Enabled = enabled;
      }

      #endregion Utilities

      // Data Manipulation
      #region Data Manipulation
      /// <summary>
      /// Obtener los registros de la tabla y asignarlos al BindingSource
      /// </summary>
      private void ReadAllPersons()
      {
         // Instanciar el Objeto de Negocio
         PersonBL personBL = new PersonBL();

         // Efectuar el llamado al Comando
         IList<Person> lstPersons = personBL.ReadAllPersons();

         // Recorrer la lista y asignar los valores
         foreach (Person person in lstPersons)
         {
            // Asignar los valores al bindSource
            bndSrcPersons.List.Add(person);

         }
      }

      /// <summary>
      ///¨Permite insertar los valores de la persona en la base de datos
      /// </summary>
      /// <param name="person">Entidad persona con los datos</param>
      private void CreatePerson(Person person)
      {
         // Instanciar el Objeto de Negocio
         PersonBL personBL = new PersonBL();

         // Ejecutar el comando
         long person_Id = personBL.CreatePerson(person);

         // Actualizar el valor de laid en la entidad person
         person.Person_Id = person_Id;
      }

      /// <summary>
      /// Borrar el Registro Actual
      /// </summary>
      private void DeletePerson()
      {
         // Obtener el registro activo
         Person person = bndSrcPersons.Current as Person;
         // Obtener el Id 
         long person_Id = person.Person_Id;

         // Validar que el Id no sea cero para no ir a la base de datos Innecesariamente
         if (!person_Id.Equals(0))
         {
            // Instanciar el Objeto de Negocio
            PersonBL personBL = new PersonBL();
            // Ejecutar el comando
            personBL.DeletePerson(person_Id);
         }

         // Eliminar el Registro
         bndSrcPersons.RemoveCurrent();
      }

      /// <summary>
      /// Actualizar los datos de la persona
      /// </summary>
      /// <param name="person">Entidad persona con los datos cambiados</param>
      private void UpdatePerson(Person person)
      {
         // Instanciar el Objeto de Negocio
         PersonBL personBL = new PersonBL();

         // Ejecutar el comando
         personBL.UpdatePerson(person);

      }
      #endregion Data Manipulation



      #endregion Privados

      #endregion Metodos

   }
}
