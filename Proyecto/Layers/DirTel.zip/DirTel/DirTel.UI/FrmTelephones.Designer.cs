﻿namespace DirTel.UI
{
   partial class FrmTelephones
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTelephones));
         this.lblPerson = new System.Windows.Forms.Label();
         this.txtPersonId = new System.Windows.Forms.TextBox();
         this.cmbPersons = new System.Windows.Forms.ComboBox();
         this.pnlTelephones = new System.Windows.Forms.Panel();
         this.dgvTelephones = new System.Windows.Forms.DataGridView();
         this.ColumnTelephoneId = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.ColumnPersonId = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.ColumnTelephoneType = new System.Windows.Forms.DataGridViewComboBoxColumn();
         this.ColumnTelephoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.ColumnTelephoneNotes = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.bndNavTelephones = new System.Windows.Forms.BindingNavigator(this.components);
         this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
         this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
         this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
         this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
         this.bindingNavigatorSaveItems = new System.Windows.Forms.ToolStripButton();
         this.pnlTelephones.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.dgvTelephones)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.bndNavTelephones)).BeginInit();
         this.bndNavTelephones.SuspendLayout();
         this.SuspendLayout();
         // 
         // lblPerson
         // 
         this.lblPerson.AutoSize = true;
         this.lblPerson.Location = new System.Drawing.Point(13, 13);
         this.lblPerson.Name = "lblPerson";
         this.lblPerson.Size = new System.Drawing.Size(52, 13);
         this.lblPerson.TabIndex = 0;
         this.lblPerson.Text = "Persona :";
         // 
         // txtPersonId
         // 
         this.txtPersonId.Location = new System.Drawing.Point(71, 10);
         this.txtPersonId.Name = "txtPersonId";
         this.txtPersonId.ReadOnly = true;
         this.txtPersonId.Size = new System.Drawing.Size(100, 20);
         this.txtPersonId.TabIndex = 1;
         // 
         // cmbPersons
         // 
         this.cmbPersons.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cmbPersons.FormattingEnabled = true;
         this.cmbPersons.Location = new System.Drawing.Point(177, 10);
         this.cmbPersons.Name = "cmbPersons";
         this.cmbPersons.Size = new System.Drawing.Size(406, 21);
         this.cmbPersons.TabIndex = 2;
         this.cmbPersons.SelectionChangeCommitted += new System.EventHandler(this.cmbPersons_SelectionChangeCommitted);
         // 
         // pnlTelephones
         // 
         this.pnlTelephones.Controls.Add(this.dgvTelephones);
         this.pnlTelephones.Controls.Add(this.bndNavTelephones);
         this.pnlTelephones.Location = new System.Drawing.Point(13, 42);
         this.pnlTelephones.Name = "pnlTelephones";
         this.pnlTelephones.Size = new System.Drawing.Size(570, 299);
         this.pnlTelephones.TabIndex = 3;
         // 
         // dgvTelephones
         // 
         this.dgvTelephones.AllowUserToAddRows = false;
         this.dgvTelephones.AllowUserToDeleteRows = false;
         this.dgvTelephones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         this.dgvTelephones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTelephoneId,
            this.ColumnPersonId,
            this.ColumnTelephoneType,
            this.ColumnTelephoneNumber,
            this.ColumnTelephoneNotes});
         this.dgvTelephones.Location = new System.Drawing.Point(4, 28);
         this.dgvTelephones.Name = "dgvTelephones";
         this.dgvTelephones.Size = new System.Drawing.Size(563, 268);
         this.dgvTelephones.TabIndex = 1;
         // 
         // ColumnTelephoneId
         // 
         this.ColumnTelephoneId.HeaderText = "TelephoneId";
         this.ColumnTelephoneId.Name = "ColumnTelephoneId";
         // 
         // ColumnPersonId
         // 
         this.ColumnPersonId.HeaderText = "PersonId";
         this.ColumnPersonId.Name = "ColumnPersonId";
         // 
         // ColumnTelephoneType
         // 
         this.ColumnTelephoneType.HeaderText = "Type";
         this.ColumnTelephoneType.Name = "ColumnTelephoneType";
         this.ColumnTelephoneType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
         this.ColumnTelephoneType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
         // 
         // ColumnTelephoneNumber
         // 
         this.ColumnTelephoneNumber.HeaderText = "Number";
         this.ColumnTelephoneNumber.Name = "ColumnTelephoneNumber";
         // 
         // ColumnTelephoneNotes
         // 
         this.ColumnTelephoneNotes.HeaderText = "Notes";
         this.ColumnTelephoneNotes.Name = "ColumnTelephoneNotes";
         // 
         // bndNavTelephones
         // 
         this.bndNavTelephones.AddNewItem = null;
         this.bndNavTelephones.CountItem = this.bindingNavigatorCountItem;
         this.bndNavTelephones.DeleteItem = null;
         this.bndNavTelephones.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.bindingNavigatorSaveItems});
         this.bndNavTelephones.Location = new System.Drawing.Point(0, 0);
         this.bndNavTelephones.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
         this.bndNavTelephones.MoveLastItem = this.bindingNavigatorMoveLastItem;
         this.bndNavTelephones.MoveNextItem = this.bindingNavigatorMoveNextItem;
         this.bndNavTelephones.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
         this.bndNavTelephones.Name = "bndNavTelephones";
         this.bndNavTelephones.PositionItem = this.bindingNavigatorPositionItem;
         this.bndNavTelephones.Size = new System.Drawing.Size(570, 25);
         this.bndNavTelephones.TabIndex = 0;
         this.bndNavTelephones.Text = "bindingNavigator1";
         // 
         // bindingNavigatorCountItem
         // 
         this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
         this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
         this.bindingNavigatorCountItem.Text = "of {0}";
         this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
         // 
         // bindingNavigatorMoveFirstItem
         // 
         this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
         this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
         this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveFirstItem.Text = "Move first";
         // 
         // bindingNavigatorMovePreviousItem
         // 
         this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
         this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
         this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMovePreviousItem.Text = "Move previous";
         // 
         // bindingNavigatorSeparator
         // 
         this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
         this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorPositionItem
         // 
         this.bindingNavigatorPositionItem.AccessibleName = "Position";
         this.bindingNavigatorPositionItem.AutoSize = false;
         this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
         this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
         this.bindingNavigatorPositionItem.Text = "0";
         this.bindingNavigatorPositionItem.ToolTipText = "Current position";
         // 
         // bindingNavigatorSeparator1
         // 
         this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
         this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorMoveNextItem
         // 
         this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
         this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
         this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveNextItem.Text = "Move next";
         // 
         // bindingNavigatorMoveLastItem
         // 
         this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
         this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
         this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorMoveLastItem.Text = "Move last";
         // 
         // bindingNavigatorSeparator2
         // 
         this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
         this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
         // 
         // bindingNavigatorAddNewItem
         // 
         this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
         this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
         this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorAddNewItem.Text = "Add new";
         this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
         // 
         // bindingNavigatorDeleteItem
         // 
         this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
         this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
         this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
         this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorDeleteItem.Text = "Delete";
         this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
         // 
         // bindingNavigatorSaveItems
         // 
         this.bindingNavigatorSaveItems.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.bindingNavigatorSaveItems.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorSaveItems.Image")));
         this.bindingNavigatorSaveItems.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.bindingNavigatorSaveItems.Name = "bindingNavigatorSaveItems";
         this.bindingNavigatorSaveItems.Size = new System.Drawing.Size(23, 22);
         this.bindingNavigatorSaveItems.Text = "SaveItems";
         this.bindingNavigatorSaveItems.ToolTipText = "Save Items";
         this.bindingNavigatorSaveItems.Click += new System.EventHandler(this.bindingNavigatorSaveItems_Click);
         // 
         // FrmTelephones
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
         this.ClientSize = new System.Drawing.Size(595, 353);
         this.Controls.Add(this.pnlTelephones);
         this.Controls.Add(this.cmbPersons);
         this.Controls.Add(this.txtPersonId);
         this.Controls.Add(this.lblPerson);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FrmTelephones";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "Telefonos";
         this.Load += new System.EventHandler(this.FrmTelephones_Load);
         this.pnlTelephones.ResumeLayout(false);
         this.pnlTelephones.PerformLayout();
         ((System.ComponentModel.ISupportInitialize)(this.dgvTelephones)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.bndNavTelephones)).EndInit();
         this.bndNavTelephones.ResumeLayout(false);
         this.bndNavTelephones.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Label lblPerson;
      private System.Windows.Forms.TextBox txtPersonId;
      private System.Windows.Forms.ComboBox cmbPersons;
      private System.Windows.Forms.Panel pnlTelephones;
      private System.Windows.Forms.DataGridView dgvTelephones;
      private System.Windows.Forms.BindingNavigator bndNavTelephones;
      private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
      private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
      private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
      private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
      private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
      private System.Windows.Forms.ToolStripButton bindingNavigatorSaveItems;
      private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTelephoneId;
      private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPersonId;
      private System.Windows.Forms.DataGridViewComboBoxColumn ColumnTelephoneType;
      private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTelephoneNumber;
      private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTelephoneNotes;
   }
}