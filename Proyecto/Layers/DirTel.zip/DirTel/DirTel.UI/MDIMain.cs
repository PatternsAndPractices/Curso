﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : MDIMain.cs                                                                     
 * Descripcion   : Formulario principal de la aplicacion que contenien el menu y el llamado a los demas 
 *                 formulario                                                      
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 23-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 23-May-2010   Jucer          1 - Version Inicial                                           
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// NameSpace
namespace DirTel.UI
{
   /// <summary>
   /// Formulario principal que contiene el Menu
   /// </summary>
   public partial class MDIMain : Form
   {
      // Constructores
      #region Constructores
      /// <summary>
      /// Construcor por defecto
      /// </summary>
      public MDIMain()
      {
         InitializeComponent();
      }
      #endregion Constructores

      // Metodos
      #region Metodos

      // Privados
      #region Privados
      /// <summary>
      /// Salir de la aplicacion
      /// </summary>
      /// <param name="sender">Menu Salir</param>
      /// <param name="e">Click</param>
      private void salirToolStripMenuItem_Click(object sender, EventArgs e)
      {
         // Cerrar el formulario principal
         this.Close();

         // Salir de la aplicacion
         Application.Exit();
      }

      /// <summary>
      /// Administrar Personas
      /// </summary>
      /// <param name="sender">Opcion Personas</param>
      /// <param name="e">Click</param>
      private void personasToolStripMenuItem_Click(object sender, EventArgs e)
      {
         // Instanciar un formulario de Personas
         FrmPersons frmPersons = new FrmPersons();

         // Asignar el formulario padre
         frmPersons.MdiParent = this;

         // Mostrar el Formulario
         frmPersons.Show();
      }

      /// <summary>
      /// Administrar Telefonos
      /// </summary>
      /// <param name="sender">Opcion Telefonos</param>
      /// <param name="e">Click</param>
      private void telefonosToolStripMenuItem_Click(object sender, EventArgs e)
      {
         // Instanciar un formulario de Telefonos
         FrmTelephones frmTelephones = new FrmTelephones();

         // Asignar el formulario padre
         frmTelephones.MdiParent = this;

         // Mostrar el Formulario
         frmTelephones.Show();
      }

      /// <summary>
      /// Ventana de Acerca de.. de la apliacion
      /// </summary>
      /// <param name="sender">Menu Acerca de</param>
      /// <param name="e">Click</param>
      private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
      {
         // Instanciar el formulario de acerca de..
         AboutBoxDirTel about = new AboutBoxDirTel();

         // asignar la ventana padre
         about.MdiParent = this;

         // Mostrar el formulario
         about.Show();
      }

      #endregion Privados

      #endregion Metodos

   }
}

