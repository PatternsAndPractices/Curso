﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : PersonDAL.cs                                                                      
 * Descripcion   : Permite acceder a los datos de la persona                                                      
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 23-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 23-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
// Librerias de ORACLE
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
// Librerias de SQLHelper
using DirTel.Data;
// Librerias de DirTel
using DirTel.Entities;

// NameSpace
namespace DirTel.DAL
{
    /// <summary>
    /// Clase para acceder a los datos de la entidad Person
    /// </summary>
    public class PersonDAL
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Cadena de conexion a la Base de datos
      private string strCnx;
      // Variable para manejar el enlace a la base de datos
      private SimpleData db;
      // Variable para manejar la conexion a la base de datos
      private IDbConnection cnx;

      #endregion Campos o Atributos

       // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public PersonDAL()
      {
         // Incicializar la cadena de conexion
         strCnx = ConfigurationManager.ConnectionStrings["DirTelCnx"].ConnectionString;
      }

      #endregion Constructores

      // Metodos
      #region Metodos

      // Publicos
      #region Publicos
      /// <summary>
      /// Inserta los datos de la Persona
      /// </summary>
      /// <param name="person">Entidad con los datos de la persona</param>
      /// <returns>Identificador de la person</returns>
      public long CreatePerson(Person person)
      {
         // Variable para retornar el id de la persona insertada
         long person_Id = 0;

         // Establecer la conexion a la base de datos
         db = SimpleData.GetSimpleData(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_PERSONS_PKG.CreatePerson";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_FirstName", person.FirstName, DbType.String);
         db.AddInParameter(cmd, "pm_LastName", person.LastName, DbType.String);
         db.AddInParameter(cmd, "pm_BirthDay", person.BirthDay, DbType.Date);
         db.AddInParameter(cmd, "pm_Sex", person.Sex, DbType.String);
         // Adicionar el parametro de salida 
         db.AddOutParameter(cmd, "pm_Person_Id", null, DbType.Int64);

         //Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Referencia rl parametro de salida para el Id de la persona
         OracleParameter outPerson_Id = cmd.Parameters[db.ParameterToken() + "pm_Person_Id"] as OracleParameter;

         // Obtener el valor del parametro
         person_Id = Convert.ToInt64(outPerson_Id.Value);

         //Cerrar la conexion
         db.CloseConnection(cnx);

         //retornar el valor 
         return person_Id;

      }

      /// <summary>
      /// Obtener todos los datos de la tabla PERSONS
      /// </summary>
      /// <returns>Lista con los datos de las personas</returns>
      public IList<Person> ReadAllPersons()
      {
         // Crear la lista para retornar los datos
         IList<Person> lstPersons = new List<Person>();

         // Establecer la conexion a la base de datos
         db = SimpleData.GetSimpleData(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando especial para ORACLE
         OracleCommand cmd = (OracleCommand)db.CreateCommand(cnx, CommandType.StoredProcedure, "DA_PERSONS_PKG.ReadAllPersons");

         // Crear el Parametro enlazado al Cursor Referenciado
         OracleParameter paramRefCursor = db.AddCommandRefCurParameter(cmd, "cur_Persons", ParameterDirection.Output, null);

         // Ejecutar el query
         db.ExecuteNonQuery(cnx, cmd);

         // Limpiar la lista

         string strData = string.Empty;

         // Obtener el Cursor Referenciado
         OracleRefCursor refCur = (OracleRefCursor)paramRefCursor.Value;
         // Obtener el DataReader desde el cursor referenciado
         OracleDataReader dr = refCur.GetDataReader();

         // Ciclo para Recorer los datos
         while (dr.Read())
         {
            // Variable Person para obtener los datos
            Person person = new Person();

            // Leer los valores
            person.Person_Id = Convert.ToInt64(dr["Person_Id"].ToString());
            person.FirstName = dr["FirstName"].ToString();
            person.LastName = dr["LastName"].ToString();
            person.BirthDay = Convert.ToDateTime(dr["BirthDay"].ToString());
            person.Sex = dr["Sex"].ToString()[0];

            // Adicionar el Valor a la lista
            lstPersons.Add(person);
         }

         // Cerar la Conexion
         db.CloseConnection(cnx);

         // retornar la lista
         return lstPersons;
      }

      /// <summary>
      /// Obtener los datos minimos de la persona (Id y Nombre Completo)
      /// </summary>
      /// <returns>Lista con los datos minimos</returns>
      public IList<PersonLight> ReadAllPersonsLight()
      {
         // Crear la lista para retornar los datos
         IList<PersonLight> lstPersonslight = new List<PersonLight>();

         // Establecer la conexion a la base de datos
         db = SimpleData.GetSimpleData(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_PERSONS_PKG.ReadAllPersonsLight";
         cmd.CommandType = CommandType.StoredProcedure;

         // Crear el Parametro enlazado al Cursor Referenciado
         OracleParameter paramRefCursor = db.AddCommandRefCurParameter((OracleCommand)cmd, "cur_Persons", ParameterDirection.Output, null);

         // Ejecutar el query
         db.ExecuteNonQuery(cnx, cmd);

         // Obtener el Cursor Referenciado
         OracleRefCursor refCur = (OracleRefCursor)paramRefCursor.Value;
         // Obtener el DataReader desde el cursor referenciado
         OracleDataReader dr = refCur.GetDataReader();

         // Ciclo para Recorer los datos
         while (dr.Read())
         {
            // Variable Person para obtener los datos
            PersonLight perLigth = new PersonLight();

            // Leer los valores
            perLigth.Person_Id = Convert.ToInt64(dr["Person_Id"].ToString());
            perLigth.FullName = dr["FullName"].ToString();

            // Adicionar el Valor a la lista
            lstPersonslight.Add(perLigth);
         }

         // Cerar la Conexion
         db.CloseConnection(cnx);

         // retornar la lista
         return lstPersonslight;
      }

      /// <summary>
      /// Borrar el Registro de la tabla segun el Id
      /// </summary>
      /// <param name="person_Id">Id de la persona</param>
      public void DeletePerson(long person_Id)
      {
         // Establecer la conexion a la base de datos
         db = SimpleData.GetSimpleData(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_PERSONS_PKG.DeletePerson";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Person_Id", person_Id, DbType.Int64);

         // Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Cerrar la conexion
         db.CloseConnection(cnx);

      }

      /// <summary>
      /// Actualiza los datos de la persona
      /// </summary>
      /// <param name="person">Datos de la Persona</param>
      public void UpdatePerson(Person person)
      {
         // Establecer la conexion a la base de datos
         db = SimpleData.GetSimpleData(ProviderType.Oracle, strCnx);

         // Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         // Crear el Comando
         IDbCommand cmd = db.CreateCommand(cnx);
         cmd.CommandText = "DA_PERSONS_PKG.UpdatePerson";
         cmd.CommandType = CommandType.StoredProcedure;
         // Asignar los parametros
         db.AddInParameter(cmd, "pm_Person_Id", person.Person_Id, DbType.Int64);
         db.AddInParameter(cmd, "pm_FirstName", person.FirstName, DbType.String);
         db.AddInParameter(cmd, "pm_LastName", person.LastName, DbType.String);
         db.AddInParameter(cmd, "pm_BirthDay", person.BirthDay, DbType.Date);
         db.AddInParameter(cmd, "pm_Sex", person.Sex, DbType.String);

         // Ejecutar el procedimiento
         int rowsAffected = db.ExecuteNonQuery(cnx, cmd);

         // Cerrar la conexion
         db.CloseConnection(cnx);

      }


      #endregion Publicos

      #endregion Metodos

   }
}
