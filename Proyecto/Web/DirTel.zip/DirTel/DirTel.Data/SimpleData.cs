﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
// Librerias de ORACLE
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
// Librerias de SQLHelper
using EandT.Framework.Base.Data;

namespace DirTel.Data
{
    public enum ProviderType
    {
        Odbc = 0,
        OleDb = 1,
        SqlServer = 2,
        Oracle = 3
    }

    public class SimpleData : ISimpleData
    {


        private static SimpleData instance;
        // Lock synchronization object
        private static object syncLock = new object();

        private static DataBase db;
        // Variable para manejar la conexion a la base de datos
        private IDbConnection cnx;

        protected SimpleData()
        {
        }

        public static SimpleData GetSimpleData()
        {
            if (instance == null)
            {
                lock (syncLock)
                {
                    if (instance == null)
                    {
                        instance = new SimpleData();
                        db = new DataBase();
                    }
                }
            }

            return instance;
        }


        public static SimpleData GetSimpleData(ProviderType providerType, string connectionString)
        {
            if (instance == null)
            {
                lock (syncLock)
                {
                    if (instance == null)
                    {
                        instance = new SimpleData();
                        db = new DataBase((EandT.Framework.Base.Data.ProviderType) providerType, connectionString);
                    }
                }
            }

            return instance;
        }

        public static SimpleData GetSimpleData(ProviderType providerType, string connectionString, int numRetry, int timeOutRetry)
        {
            if (instance == null)
            {
                lock (syncLock)
                {
                    if (instance == null)
                    {
                        instance = new SimpleData();
                        db = new DataBase((EandT.Framework.Base.Data.ProviderType)providerType,  connectionString,  numRetry,  timeOutRetry);
                    }
                }
            }

            return instance;
        }


        public void Close(IDbConnection connection)
        {
            if (db != null)
            {
                if (db.IsConnectionOpen(connection))
                {
                    db.CloseConnection(connection);
                }
            }
        }

        public string ConnectionString
        {
            get
            {
                return db.ConnectionString;
            }

            set
            {
                db.ConnectionString = value;
            }
        }

        public int NumRetry
        {
            get
            {
                return db.NumRetry;
            }

            set
            {
                db.NumRetry = value;
            }
        }

        public int TimeOutRetry
        {
            get
            {
                return db.TimeOutRetry;
            }

            set
            {
                db.TimeOutRetry = value;
            }
        }

        public void AddCommandParameter(IDbCommand command, string name, object value, DbType dbType)
        {
            db.AddCommandParameter( command,  name,  value,  dbType);
        }

        public void AddCommandParameter(IDbCommand command, string name, ParameterDirection direction, object value, DbType dbType)
        {
            db.AddCommandParameter( command,  name,  direction,  value,  dbType);
        }

        public IDataParameter AddCommandParameterReturnValueType(IDbCommand command)
        {
            return db.AddCommandParameterReturnValueType( command);
        }

        public OracleParameter AddCommandRefCurParameter(OracleCommand command, string name, ParameterDirection direction, object value)
        {
            return db.AddCommandRefCurParameter( command,  name,  direction,  value);
        }

        public void AddInParameter(IDbCommand command, string name, object value, DbType dbType)
        {
            db.AddInParameter( command,  name,  value,  dbType);
        }

        public void AddInParameter(IDbCommand command, string name, object value, int size, DbType dbType)
        {
            db.AddInParameter( command,  name,  value,  size,  dbType);
        }

        public void AddIOParameter(IDbCommand command, string name, object value, DbType dbType)
        {
            db.AddIOParameter( command,  name,  value,  dbType);
        }

        public void AddOutParameter(IDbCommand command, string name, object value, DbType dbType)
        {
            db.AddOutParameter( command,  name,  value,  dbType);
        }

        public void AddOutParameter(IDbCommand command, string name, object value, int size, DbType dbType)
        {
            db.AddOutParameter( command,  name,  value,  size,  dbType);
        }

        public DbTransaction BeginTransaction(DbConnection connection)
        {
            return db.BeginTransaction( connection);
        }

        public string BuildParameterName(string name)
        {
            return db.BuildParameterName( name);
        }

        public void CloseConnection(IDbConnection connection)
        {
            //db.CloseConnection(connection);
        }

        public void CommitTransaction(DbTransaction tran)
        {
            db.CommitTransaction( tran);
        }

        public IDbConnection CreateAndOpenConnection()
        {
            if ((cnx == null) || (!db.IsConnectionOpen(cnx))) 
            {
                this.cnx = db.CreateAndOpenConnection();
            }

            //if (!db.IsConnectionOpen(cnx))
            //{
            //    this.cnx = db.CreateAndOpenConnection();
            //}
                   
            return cnx;
        }

        public IDbCommand CreateCommand(IDbConnection connection)
        {
            return db.CreateCommand(connection);
        }

        public IDbCommand CreateCommand(IDbConnection connection, CommandType commandType, string commandText)
        {
            return db.CreateCommand( connection,  commandType,  commandText);
        }

        public IDbConnection CreateConnection()
        {
            return db.CreateConnection();
        }

        public DataSet ExecuteDataSet(IDbConnection connection, IDbCommand command)
        {
            return db.ExecuteDataSet( connection,  command);
        }

        public DataSet ExecuteDataSet(IDbConnection connection, string query)
        {
            return db.ExecuteDataSet( connection,  query);
        }

        public DataTable ExecuteDataTable(IDbConnection connection, IDbCommand command)
        {
            return db.ExecuteDataTable( connection,  command);
        }

        public DataTable ExecuteDataTable(IDbConnection connection, string query)
        {
            return db.ExecuteDataTable( connection,  query);
        }

        public int ExecuteNonQuery(IDbConnection connection, IDbCommand command)
        {
            return db.ExecuteNonQuery( connection,  command);
        }

        public int ExecuteNonQuery(IDbConnection connection, string query)
        {
            return db.ExecuteNonQuery( connection,  query);
        }

        public IDataReader ExecuteReader(IDbConnection connection, IDbCommand command)
        {
            return db.ExecuteReader( connection,  command);
        }

        public IDataReader ExecuteReader(IDbConnection connection, string query)
        {
            return db.ExecuteReader( connection,  query);
        }

        public object ExecuteScalar(IDbConnection connection, IDbCommand command)
        {
            return db.ExecuteScalar( connection,  command);
        }

        public object ExecuteScalar(IDbConnection connection, string query)
        {
            return db.ExecuteScalar( connection,  query);
        }

        public IDbCommand GetStoredProcCommand(IDbConnection connection, string storedProcedureName)
        {
            return db.GetStoredProcCommand( connection,  storedProcedureName);
        }

        public IDbCommand GetStoredProcCommand(IDbConnection connection, string storedProcedureName, params object[] parameterValues)
        {
            return db.GetStoredProcCommand( connection,  storedProcedureName,  parameterValues);
        }

        public bool IsConnectionOpen(IDbConnection connection)
        {
            return db.IsConnectionOpen( connection);
        }

        public void OpenConnection(IDbConnection connection)
        {
            db.OpenConnection( connection);
        }

        public string ParameterToken()
        {
            return db.ParameterToken();
        }

        public void RollbackTransaction(DbTransaction tran)
        {
            db.RollbackTransaction( tran);
        }

        public void SetParameterValue(DbCommand command, string parameterName, object value)
        {
            db.SetParameterValue( command,  parameterName,  value);
        }
    }
}
