﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Person.cs                                                                      
 * Descripcion   : Entidad para manejar los datos de las personas                                        
 * Autor         : Julio Cesar Robles Uribe - Jucer                                              
 * Fecha         : 21-May-2010                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 21-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.Text;

// NameSpace
namespace DirTel.Entities
{
   /// <summary>
   /// Entidad Persona
   /// </summary>
   public class Person
   {
      // Campos o Atributos
      #region Campos o Atributos
      // Identificador de la persona
      private long person_Id;
      // Nombres de la Persona
      private string firstName;
      // Apellidos de la Persona
      private string lastName;
      // Fecha de Nacimiento (dd-mm-yyyy)
      private DateTime birthDay;
      // Sexo (M,F)
      private char sex;

      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      /// <summary>
      /// Identificador de la persona
      /// </summary>
      public long Person_Id
      {
         get
         {
            return person_Id;
         }
         set
         {
            person_Id = value;
         }
      }

      /// <summary>
      /// Nombres de la Persona
      /// </summary>
      public string FirstName
      {
         get
         {
            return firstName;
         }
         set
         {
            firstName = value;
         }
      }

      /// <summary>
      /// Apellidos de la Persona
      /// </summary>
      public string LastName
      {
         get
         {
            return lastName;
         }
         set
         {
            lastName = value;
         }
      }

      /// <summary>
      /// Fecha de Nacimiento (dd-mm-yyyy)
      /// </summary>
      public DateTime BirthDay
      {
         get
         {
            return birthDay;
         }
         set
         {
            birthDay = value;
         }
      }

      /// <summary>
      /// Sexo (M,F)
      /// </summary>
      public char Sex
      {
         get
         {
            return sex;
         }
         set
         {
            sex = value;
         }
      }

      #endregion Propiedades

      // Constructores
      #region Constructores
      /// <summary>
      /// Constructor por defecto
      /// </summary>
      public Person()
      {
         //Identificador de la persona
         person_Id = 0;
         //Nombres de la Persona
         firstName = string.Empty;
         //Apellidos de la Persona
         lastName = string.Empty;
         //Fecha de Nacimiento (dd-mm-yyyy)
         birthDay = DateTime.Now;
         //Sexo (M,F)
         sex = 'M';
      }

      /// <summary>
      /// Constructor con campos
      /// </summary>
      /// <param name="firstName">Nombres</param>
      /// <param name="lastName">Apellidos</param>
      /// <param name="birthDay">Fecha de Nacimiento</param>
      /// <param name="sex">Sexo (M,F)</param>
      public Person(string firstName, string lastName, DateTime birthDay, char sex)
      {
         //Nombres de la Persona
         this.firstName = firstName;
         //Apellidos de la Persona
         this.lastName = lastName;
         //Fecha de Nacimiento (dd-mm-yyyy)
         this.birthDay = birthDay;
         //Sexo (M,F)
         this.sex = sex;
      }


      #endregion Constructores

   }
}
