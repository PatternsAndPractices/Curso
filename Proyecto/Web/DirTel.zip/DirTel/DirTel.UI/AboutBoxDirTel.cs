﻿#region Documentación
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : AboutBoxDirTel.cs                                                                    
 * Descripcion   : Formulario Acerca de .. de la apliacion
 * Autor         : Julio Cesar Robles Uribe - Jucer
 * Fecha         : 29-May-2010
 *                                                                                                           
 * Fecha         Autor          Modificación                                                                 
 * ===========   ============   ============================================================================ 
 * 29-May-2010   Jucer          1 - Version Inicial                                                          
 ***********************************************************************************************************/
#endregion Documentación

// Librerias
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

// NameSpace
namespace DirTel.UI
{
   /// <summary>
   /// Formulario de Acerca de
   /// </summary>
   partial class AboutBoxDirTel : Form
   {
      // Constructores
      #region Constructores
      /// <summary>
      /// Constrcutor por defecto
      /// </summary>
      public AboutBoxDirTel()
      {
         InitializeComponent();
         this.Text = String.Format("About {0}", AssemblyTitle);
         this.labelProductName.Text = AssemblyProduct;
         this.labelVersion.Text = String.Format("Version {0}", AssemblyVersion);
         this.labelCopyright.Text = AssemblyCopyright;
         this.labelCompanyName.Text = AssemblyCompany;
         this.textBoxDescription.Text = AssemblyDescription;
      }

      #endregion Constructores

      // Propiedades
      #region Propiedades

      // Obtener los datos del Assembly
      #region Assembly Attribute Accessors

      /// <summary>
      /// Obtener el Titulo del Assembly
      /// </summary>
      public string AssemblyTitle
      {
         get
         {
            object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
            if (attributes.Length > 0)
            {
               AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
               if (titleAttribute.Title != "")
               {
                  return titleAttribute.Title;
               }
            }
            return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
         }
      }

      /// <summary>
      /// Obtener la version del Assembly
      /// </summary>
      public string AssemblyVersion
      {
         get
         {
            return Assembly.GetExecutingAssembly().GetName().Version.ToString();
         }
      }

      /// <summary>
      /// Obtener la descripcion del Assembly
      /// </summary>
      public string AssemblyDescription
      {
         get
         {
            object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
            if (attributes.Length == 0)
            {
               return "";
            }
            return ((AssemblyDescriptionAttribute)attributes[0]).Description;
         }
      }

      /// <summary>
      /// Obtener el Producto
      /// </summary>
      public string AssemblyProduct
      {
         get
         {
            object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
            if (attributes.Length == 0)
            {
               return "";
            }
            return ((AssemblyProductAttribute)attributes[0]).Product;
         }
      }

      /// <summary>
      /// Obtner los derechos de autor
      /// </summary>
      public string AssemblyCopyright
      {
         get
         {
            object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
            if (attributes.Length == 0)
            {
               return "";
            }
            return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
         }
      }

      /// <summary>
      /// Obtener la Empresa
      /// </summary>
      public string AssemblyCompany
      {
         get
         {
            object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
            if (attributes.Length == 0)
            {
               return "";
            }
            return ((AssemblyCompanyAttribute)attributes[0]).Company;
         }
      }

      #endregion Assembly Attribute Accessors

      #endregion Propiedades

      // Metodos
      #region Metodos
      /// <summary>
      /// Aceptar la informacion y cerrar el formulario
      /// </summary>
      /// <param name="sender">Boton Ok</param>
      /// <param name="e">Click</param>
      private void okButton_Click(object sender, EventArgs e)
      {
         // Cerrar el formulario
         this.Close();
      }
      #endregion Metodos

   }
}

