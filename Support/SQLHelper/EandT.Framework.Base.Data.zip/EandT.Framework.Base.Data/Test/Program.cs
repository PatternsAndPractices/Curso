using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Text;

//Librerias de ORACLE
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
//Librerias de OpenSystems
using EandT.Framework.Base.Data;

namespace Test
{
   class Program
   {


      //Campos o Atributos
      #region Campos o Atributos
      //Cadena de conexion a la Base de datos
      private static string strCnx;
      //Variable para manejar el enlace a la base de datos
      private static DataBase db;
      //Variable para manejar la conexion a la base de datos
      private static IDbConnection cnx;
      #endregion Campos o Atributos

      static void Main(string[] args)
      {
         //Obtener el valor de la variale PATH
         string path = Environment.GetEnvironmentVariable("PATH");

         //Obtener el directorio donde se encuentra instalado el Oracle Data Provider (ODP)
         string dirODP = ConfigurationManager.AppSettings["DirODP"].ToString();

         //Adicionar el directorio del ODP al inicio de la variable PATH
         Environment.SetEnvironmentVariable("PATH", dirODP + ";" + path);

         //Incicialiar la cadena de conexion
         strCnx = ConfigurationManager.ConnectionStrings["CVIRTU01Cnx"].ConnectionString;

         DataSet ds = RetriveAllPresons();
         DataTable dt = ds.Tables[0];
         foreach (DataRow dr in dt.Rows)
         {
            foreach (DataColumn col in dt.Columns)
            {
               Console.WriteLine(dr[col]);
            }
            Console.WriteLine("".PadLeft(20, '='));
         }
      }


      public static DataSet RetriveAllPresons()
      {
         //Crear el Dtaset a retornar
         DataSet ds = null;

         //Establecer la conexion a la base de datos
         db = new DataBase(ProviderType.Oracle, strCnx);

         //Crear la Conexion
         cnx = db.CreateAndOpenConnection();

         //Crear el Comando especial para ORACLE
         OracleCommand cmd = (OracleCommand)db.CreateCommand(cnx, CommandType.StoredProcedure, "DA_PERSONS_PKG.ReadAllPersons");

         //Crear el Parametro enlazado al Cursor Referenciado
         OracleParameter paramRefCursor = db.AddCommandRefCurParameter(cmd, "cur_Persons", ParameterDirection.Output, null);

         //Ejecutar el query
         ds = db.ExecuteDataSet(cnx, cmd);

         //Cerar la Conexion
         db.CloseConnection(cnx);

         //retornar la lista
         return ds;
      }
   }
}
