#region Documentaci�n
/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : <Nombre de la Clase>                                                                      
 * Descripcion   : <Objetivo o descripcion de la clase>                                                      
 * Autor         : <Nombre completo del ingeniero> - <nickname>                                              
 * Fecha         : <dd-MMM-yyyy>                                                                             
 *                                                                                                           
 * Fecha         Autor          Modificaci�n                                                                 
 * ===========   ============   ============================================================================ 
 * dd-MMM-yyyy   <nickname>     1 - Version Inicial                                                          
 *                              2 - Detalle del cambio o modificacion                                        
 ***********************************************************************************************************/
#endregion Documentaci�n

// Librerias
using System;
using System.Collections.Generic;
using System.Text;

// NameSpace
namespace <Empresa>.<Proyecto>.<NameSpace Base>.<NameSpace Derivado>
{

   // Enumeraciones
   #region Enumeraciones
   #endregion Enumeraciones
   

   /// <summary>
   /// Descripcion del objetivo de la clase
   /// </summary>
   public class <Nombre de la Clase>
   {

      // Constantes
      #region Constantes
      #endregion Constantes
      
      // Campos o Atributos
      #region Campos o Atributos
      #endregion Campos o Atributos

      // Propiedades
      #region Propiedades
      #endregion Propiedades

      // Constructores
      #region Constructores
      #endregion Constructores

      // Metodos
      #region Metodos

      // Publicos
      #region Publicos
      #endregion Publicos

      // Privados
      #region Privados
      #endregion Privados

      #endregion Metodos

   }
}
