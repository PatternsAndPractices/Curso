/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Persons_Seq.sql                                                                      
 * Descripcion   : Realiza la creacion de la sequencia AUTONUMBER para tabla PERSONS sobre el campo 
 *                 PERSON_ID
 * Autor         : Julio Cesar Robles Uribe - JuCeR (jrobles)                                                
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========  ============   ============================================================================ 
 * 21-May-2010  Jucer          1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
DROP SEQUENCE PERSONS_SEQ;
CREATE SEQUENCE PERSONS_SEQ
MINVALUE 1
START WITH 1
INCREMENT BY 1
NOCACHE;



