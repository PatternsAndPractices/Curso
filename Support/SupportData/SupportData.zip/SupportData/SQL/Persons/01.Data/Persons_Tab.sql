/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Persons_Tab.sql                                                                      
 * Descripcion   : Realiza la creacion de la tabla PERSONS
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========  ============   ============================================================================ 
 * 21-May-2010  Jucer          1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
 
CREATE TABLE PERSONS 
(	
  PERSON_ID    NUMBER(6,0)    NOT NULL PRIMARY KEY
, FIRSTNAME    VARCHAR2(40)   NOT NULL
, LASTNAME     VARCHAR2(40)   NOT NULL
, BIRTHDAY     DATE           NOT NULL
, SEX          VARCHAR2(1)    NOT NULL
) TABLESPACE USERS ;
 
