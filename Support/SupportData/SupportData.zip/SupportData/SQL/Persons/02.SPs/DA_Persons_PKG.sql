/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : DA_Persons_PKG.sql                                                                      
 * Descripcion   : Realiza la creacion del paquete para manejar los datos de la tabla PERSONS
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========  ============   ============================================================================ 
 * 21-May-2010  Jucer          1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
CREATE OR REPLACE PACKAGE DA_PERSONS_PKG IS
   
    /*===========*
    * Constantes *
    *===========*/

    /*======*
    * Tipos *
    *======*/
    -- Tipo usado para manipular Cursores Referenciados
   TYPE typeRefCursor IS REF CURSOR;
    
    /*==========*
    * Variables *
    *==========*/

    /*=========*
    * Cursores *
    *=========*/
    
    /*=================*
    * Metodos Publicos *
    *=================*/
   
   --********************************************************************************************************
   --* Procedimiento : CreatePerson
   --* Objetivo      : Insertar o Crear un registro en la tabla PERSON
   --* Parametros    :
   --* - IN firstName : Nombres de la Persona
   --* - IN lastNAme  : Apellidos de la Persona
   --* - IN birthDay  : Fecha de Nacimiento de la Persona en formato dd-mm-yyyy
   --* - IN sex       : Sexo de la persona (M,F)
   --********************************************************************************************************
   PROCEDURE CreatePerson
   (
     pm_FirstName       IN    VARCHAR2
   , pm_LastName        IN    VARCHAR2
   , pm_BirthDay        IN    DATE
   , pm_Sex             IN    VARCHAR2
   , pm_Person_Id       OUT   NUMBER
   
   );

   --********************************************************************************************************
   --* Procedimiento : ReadPersonById
   --* Objetivo      : Leer los datos de un registro de la tabla PERSON por Identificador
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadPersonById
   (
     pm_Person_Id       IN   NUMBER 
   , cur_Persons     OUT  typeRefCursor
   );
   
   --********************************************************************************************************
   --* Procedimiento : ReadAllPersons
   --* Objetivo      : Leer los datos todos los registros de la tabla PERSON
   --* Parametros    :
  --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadAllPersons
   (
     cur_Persons     OUT typeRefCursor
   );  
   

   --********************************************************************************************************
   --* Procedimiento : ReadAllPersonsLight
   --* Objetivo      : Leer los datos todos los registros de la tabla PERSON, trayendo el Id, Nombres
   --*                 y Apellidos
   --* Parametros    :
  --* - OUT cur_Persons : Cursor de Salida
   --********************************************************************************************************
   PROCEDURE ReadAllPersonsLight
   (
     cur_Persons     OUT typeRefCursor
   );
   
   --********************************************************************************************************
   --* Procedimiento : UpdatePerson
   --* Objetivo      : Actualiza un registro en la tabla PERSON
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --* - IN firstName : Nombres de la Persona
   --* - IN lastNAme  : Apellidos de la Persona
   --* - IN birthDay  : Fecha de Nacimiento de la Persona en formato dd-mm-yyyy
   --* - IN sex       : Sexo de la persona (M,F)
   --********************************************************************************************************   
   PROCEDURE UpdatePerson
   (
     pm_Person_Id       IN NUMBER  
   , pm_FirstName       IN VARCHAR2   DEFAULT NULL
   , pm_LastName        IN VARCHAR2   DEFAULT NULL
   , pm_BirthDay        IN DATE       DEFAULT NULL
   , pm_Sex             IN VARCHAR2   DEFAULT NULL
   );

   --********************************************************************************************************
   --* Procedimiento : DeletePerson
   --* Objetivo      : Borra un registro en la tabla PERSON
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --********************************************************************************************************   
   PROCEDURE DeletePerson
   (
    pm_Person_Id     IN  NUMBER  
   );
     

END DA_PERSONS_PKG;