/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : DA_Persons_PKG_Body.sql                                                                      
 * Descripcion   : Realiza la creacion del paquete para manejar los datos de la tabla PERSONS
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========  ============   ============================================================================ 
 * 21-May-2010  Jucer          1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
CREATE OR REPLACE PACKAGE BODY DA_PERSONS_PKG AS
   --********************************************************************************************************
   --* Procedimiento : CreatePerson
   --* Objetivo      : Insertar o Crear un registro en la tabla PERSON
   --* Parametros    :
   --* - IN firstName : Nombres de la Persona
   --* - IN lastNAme  : Apellidos de la Persona
   --* - IN birthDay  : Fecha de Nacimiento de la Persona en formato dd-mm-yyyy
   --* - IN sex       : Sexo de la persona (M,F)
   --********************************************************************************************************
   PROCEDURE CreatePerson
   (
     pm_FirstName       IN    VARCHAR2
   , pm_LastName        IN    VARCHAR2
   , pm_BirthDay        IN    DATE
   , pm_Sex             IN    VARCHAR2
   , pm_Person_Id       OUT   NUMBER
   ) AS
   BEGIN
      -- Obtener el Id de la Persona
      SELECT PERSONS_SEQ.NEXTVAL INTO pm_Person_Id FROM DUAL ;
      
      --Insertar el Valor
      INSERT INTO PERSONS 
      (
        PERSON_ID
      , FIRSTNAME
      , LASTNAME
      , BIRTHDAY
      , SEX
      )
      VALUES
      ( 
        pm_Person_Id 
      , pm_FirstName
      , pm_LastName
      , pm_BirthDay
      , pm_Sex
      );
   END CreatePerson;

      --********************************************************************************************************
   --* Procedimiento : ReadPersonById
   --* Objetivo      : Leer los datos de un registro de la tabla PERSON por Identificador
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadPersonById
   (
     pm_Person_Id       IN   NUMBER 
   , cur_Persons     OUT  typeRefCursor
   ) AS
   BEGIN
      OPEN cur_Persons FOR 
           SELECT PERSON_ID
                , FIRSTNAME
                , LASTNAME
                , BIRTHDAY
                , SEX
           FROM PERSONS
           WHERE PERSON_ID = pm_Person_Id;
   END ReadPersonById;

   --********************************************************************************************************
   --* Procedimiento : ReadAllPersons
   --* Objetivo      : Leer los datos todos los registros de la tabla PERSON
   --* Parametros    :
  --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadAllPersons
   (
     cur_Persons     OUT typeRefCursor
   ) AS
   BEGIN
      OPEN cur_Persons FOR 
           SELECT PERSON_ID
                , FIRSTNAME
                , LASTNAME
                , BIRTHDAY
                , SEX
           FROM PERSONS
           ORDER BY PERSON_ID;
   END ReadAllPersons;
   
   --********************************************************************************************************
   --* Procedimiento : ReadAllPersonsLight
   --* Objetivo      : Leer los datos todos los registros de la tabla PERSON, trayendo el Id, Nombres
   --*                 y Apellidos
   --* Parametros    :
  --* - OUT cur_Persons : Cursor de Salida
   --********************************************************************************************************
   PROCEDURE ReadAllPersonsLight
   (
     cur_Persons     OUT typeRefCursor
   ) AS
   BEGIN
      OPEN cur_Persons FOR
           SELECT PERSON_ID
                , FIRSTNAME || ' ' || LASTNAME FULLNAME
           FROM PERSONS
           ORDER BY FIRSTNAME;
   END ReadAllPersonsLight;


   --********************************************************************************************************
   --* Procedimiento : UpdatePerson
   --* Objetivo      : Actualizar un registro en la tabla PERSON
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --* - IN firstName : Nombres de la Persona
   --* - IN lastNAme  : Apellidos de la Persona
   --* - IN birthDay  : Fecha de Nacimiento de la Persona en formato dd-mm-yyyy
   --* - IN sex       : Sexo de la persona (M,F)
   --******************************************************************************************************** 
   PROCEDURE UpdatePerson
   (
     pm_Person_Id       IN NUMBER  
   , pm_FirstName       IN VARCHAR2   DEFAULT NULL
   , pm_LastName        IN VARCHAR2   DEFAULT NULL
   , pm_BirthDay        IN DATE       DEFAULT NULL
   , pm_Sex             IN VARCHAR2   DEFAULT NULL
   ) AS
   BEGIN
     UPDATE PERSONS
     SET FIRSTNAME = NVL(pm_FirstName, FIRSTNAME)
       , LASTNAME = NVL(pm_LastName, LASTNAME)
       , BIRTHDAY = NVL(pm_BirthDay, BIRTHDAY)
       , SEX = NVL(pm_Sex, SEX)
     WHERE PERSON_ID = pm_Person_Id;
   END UpdatePerson;

   --********************************************************************************************************
   --* Procedimiento : DeletePerson
   --* Objetivo      : Borra un registro en la tabla PERSON
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona a actualizar
   --******************************************************************************************************** 
   PROCEDURE DeletePerson
   (
    pm_Person_Id     IN  NUMBER  
   ) AS
   BEGIN
      DELETE PERSONS WHERE PERSON_ID = pm_Person_id;
   END DeletePerson;

END DA_PERSONS_PKG;