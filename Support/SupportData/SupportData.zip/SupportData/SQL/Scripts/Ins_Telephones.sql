INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 1, 1, '3711765 ', 'Llmar despues de las 8 p.m.');
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 1, 2, '3185526543', '');
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 1, 3, '3319999 Ext. 142', 'Llamar en Horaro de oficina');
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 2, 1, '3326548', null);
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 2, 2, '3155582741', null);
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 3, 2, '3214567890', null);
INSERT INTO Telephones (Telephone_Id, Person_Id, Telephone_Type, Telephone_Number, Notes) VALUES (TELEPHONES_SEQ.NEXTVAL, 3, 3, '6605237 Ext 1389', 'Telefono de Assenda');
