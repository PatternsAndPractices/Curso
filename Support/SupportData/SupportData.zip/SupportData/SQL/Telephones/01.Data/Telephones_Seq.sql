/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Telephones_Seq.sql                                                                      
 * Descripcion   : Realiza la creacion de la sequencia AUTONUMBER para tabla TELEPHONES sobre el campo 
 *                 TELEPHONE_ID
 * Autor         : Julio Cesar Robles Uribe - JuCeR (jrobles)                                                
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========   ============   ============================================================================ 
 * 21-May-2010  Jucer        1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
DROP SEQUENCE TELEPHONES_SEQ;
CREATE SEQUENCE TELEPHONES_SEQ
MINVALUE 1
START WITH 1
INCREMENT BY 1
NOCACHE;



