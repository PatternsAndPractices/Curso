/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : Telephones_Tab.sql                                                                      
 * Descripcion   : Realiza la creacion de la tabla TELEPHONES
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========   ============   ============================================================================ 
 * 21-May-2010  Jucer        1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
 
CREATE TABLE TELEPHONES 
(	
  TELEPHONE_ID      NUMBER(6,0)    NOT NULL PRIMARY KEY
, PERSON_ID         NUMBER(6,0)    NOT NULL 
, TELEPHONE_TYPE    NUMBER(2,0)    NOT NULL 
, TELEPHONE_NUMBER  VARCHAR2(40)   NOT NULL
, NOTES             VARCHAR2(40)   NULL
) TABLESPACE USERS ;
 
-- FOREING KEYS
ALTER TABLE TELEPHONES
ADD CONSTRAINT FK_TELEPHONES_PERSONS FOREIGN KEY
(
  PERSON_ID 
)
REFERENCES PERSONS
(
  PERSON_ID 
)
ENABLE;
