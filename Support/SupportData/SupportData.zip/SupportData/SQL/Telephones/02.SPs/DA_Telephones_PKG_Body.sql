/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : DA_Telephones_PKG_Body.sql                                                                      
 * Descripcion   : Realiza la creacion del paquete para manejar los datos de la tabla TELEPHONES
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========  ============   ============================================================================ 
 * 21-May-2010  Jucer          1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
CREATE OR REPLACE PACKAGE BODY DA_TELEPHONES_PKG AS
   --********************************************************************************************************
   --* Procedimiento : CreateTelephone
   --* Objetivo      : Insertar o Crear un registro en la tabla TELEPHONES
   --* Parametros    :
   --* - IN Person_Id : Identificador de la Persona
   --* - IN Telephone_Type : Identificador del tipo de telefono (1-Home 2-Mobile 3-Work)
   --* - IN Telephone_Number : CAena para el Numero del Telefono, par ainclir numeros y letras
   --* - IN Notes : Notas adicionales para el telefono
   --* - OUT Telephone_Id : Identificador del telefono despues de ser insertado
   --********************************************************************************************************    
   PROCEDURE CreateTelephone
   (
     pm_Person_Id           IN    NUMBER
   , pm_Telephone_Type      IN    NUMBER
   , pm_Telephone_Number    IN    VARCHAR2
   , pm_Notes               IN    VARCHAR2
   , pm_Telephone_Id        OUT   NUMBER
   ) AS
   BEGIN
      -- Obtener el Id
      SELECT TELEPHONES_SEQ.NEXTVAL INTO pm_Telephone_Id FROM DUAL ;
      
      --Insertar el Valor
      INSERT INTO TELEPHONES
      (
        TELEPHONE_ID
      , PERSON_ID
      , TELEPHONE_TYPE
      , TELEPHONE_NUMBER
      , NOTES
      )
      VALUES
      ( 
        pm_Telephone_Id
      , pm_Person_Id
      , pm_Telephone_Type
      , pm_Telephone_Number
      , pm_Notes
      );
   END CreateTelephone;


   --********************************************************************************************************
   --* Procedimiento : ReadTelephonesByPersonId
   --* Objetivo      : Leer los datos de los telefonos que estan asociados una persona
   --* Parametros    :
   --* - IN person_Id : Identificador de la Persona 
   --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadTelephonesByPersonId
   (
     pm_Person_Id       IN   NUMBER
   , cur_Telephones     OUT  typeRefCursor
   ) AS
   BEGIN
      OPEN cur_Telephones FOR
           SELECT TELEPHONE_ID
                , PERSON_ID
                , TELEPHONE_TYPE
                , TELEPHONE_NUMBER
                , NOTES
           FROM TELEPHONES
           WHERE PERSON_ID = pm_Person_Id;
   END ReadTelephonesByPersonId;


   --********************************************************************************************************
   --* Procedimiento : ReadAllTelephones
   --* Objetivo      : Leer todos los datos de los telefonos
   --* Parametros    :
   --* - OUT cur_Persons : Cursor de Salida    
   --********************************************************************************************************
   PROCEDURE ReadAllTelephones
   (
     cur_Telephones     OUT typeRefCursor
   ) AS
   BEGIN
      OPEN cur_Telephones FOR
           SELECT TELEPHONE_ID
                , PERSON_ID
                , TELEPHONE_TYPE
                , TELEPHONE_NUMBER
                , NOTES
           FROM TELEPHONES
           ORDER BY PERSON_ID;
   END ReadAllTelephones;
   
   --********************************************************************************************************
   --* Procedimiento : UpdateTelephone
   --* Objetivo      : Actualiza un registro en la tabla TELEPHONES
   --* Parametros    :
   --* - IN Telephone_Id : Identificador del telefono 
   --* - IN Person_Id : Identificador de la Persona
   --* - IN Telephone_Type : Identificador del tipo de telefono (1-Home 2-Mobile 3-Work)
   --* - IN Telephone_Number : CAena para el Numero del Telefono, par ainclir numeros y letras
   --* - IN Notes : Notas adicionales para el telefono
   --********************************************************************************************************   
   PROCEDURE UpdateTelephone
   (
     pm_Telephone_Id        IN    NUMBER
   , pm_Person_Id           IN    NUMBER
   , pm_Telephone_Type      IN    NUMBER
   , pm_Telephone_Number    IN    VARCHAR2
   , pm_Notes               IN    VARCHAR2  DEFAULT NULL
   ) AS
   BEGIN
     UPDATE TELEPHONES
     SET PERSON_ID = NVL(pm_Person_Id, PERSON_ID)
       , TELEPHONE_TYPE = NVL(pm_Telephone_Type, TELEPHONE_TYPE)
       , TELEPHONE_NUMBER = NVL(pm_Telephone_Number, TELEPHONE_NUMBER)
       , NOTES = NVL(pm_Notes, NOTES)
     WHERE TELEPHONE_ID = pm_Telephone_Id;
   END UpdateTelephone;

   --********************************************************************************************************
   --* Procedimiento : DeleteTelephone
   --* Objetivo      : Borra un registro en la tabla TELEPHONES
   --* Parametros    :
   --* - IN Telephone_Id : Identificador del telefono 
   --********************************************************************************************************   
   PROCEDURE DeleteTelephone
   (
    pm_Telephone_Id     IN  NUMBER
   ) AS
   BEGIN
      DELETE TELEPHONES WHERE TELEPHONE_ID = pm_Telephone_Id;
   END DeleteTelephone;

END DA_TELEPHONES_PKG;