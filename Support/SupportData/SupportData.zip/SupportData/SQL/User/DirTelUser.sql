/************************************************************************************************************
 * Propiedad intelectual de Engineers & Tools (c).                                                           
 ************************************************************************************************************
 * Unidad        : DirTelUser.sql                                                                      
 * Descripcion   : Realiza la creacion del usuario DirTelUser
 * Autor         : Julio Cesar Robles Uribe - Jucer                                               
 * Fecha         : 21-May-2010                                                                               
 *                                                                                                           
 * Fecha        Autor          Modificaci�n                                                          
 * ===========   ============   ============================================================================ 
 * 21-May-2010  Jucer        1 - Version Inicial                                                   
 ***********************************************************************************************************/ 
-- USER SQL
CREATE USER DirTelUser IDENTIFIED BY DirTelPwd 
DEFAULT TABLESPACE "USERS"
TEMPORARY TABLESPACE "TEMP";

-- ROLES
GRANT "RESOURCE" TO DirTelUser WITH ADMIN OPTION;
GRANT "DBA" TO DirTelUser WITH ADMIN OPTION;
ALTER USER DirTelUser DEFAULT ROLE "RESOURCE","DBA";

-- SYSTEM PRIVILEGES
GRANT UNLIMITED TABLESPACE TO DirTelUser ;

-- QUOTAS
ALTER USER DirTelUser QUOTA UNLIMITED ON USERS;
